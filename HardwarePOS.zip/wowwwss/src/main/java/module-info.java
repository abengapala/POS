module com.hardwarestore.pos {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.swing; // 👈 Needed for WebcamPanel (Swing GUI)
    requires java.sql;
    requires java.base;
    requires webcam.capture; // 👈 This is for the webcam library
    requires com.google.zxing; // 👈 ZXing core
    requires com.google.zxing.javase; // 👈 ZXing Java SE helper

    opens com.hardwarestore.pos to javafx.fxml;
    opens com.hardwarestore.pos.view to javafx.fxml;

    exports com.hardwarestore.pos;
    exports com.hardwarestore.pos.view;
}
