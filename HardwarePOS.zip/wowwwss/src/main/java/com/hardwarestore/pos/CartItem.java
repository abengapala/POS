package com.hardwarestore.pos;

import javafx.beans.property.*;

public class CartItem {
    private final int productId;
    private final StringProperty productName;
    private final DoubleProperty price;
    private final IntegerProperty quantity;
    private final DoubleProperty total;

    public CartItem(int productId, String name, double price, int quantity) {
        this.productId = productId;
        this.productName = new SimpleStringProperty(name);
        this.price = new SimpleDoubleProperty(price);
        this.quantity = new SimpleIntegerProperty(quantity);
        this.total = new SimpleDoubleProperty(price * quantity);

        this.quantity.addListener((obs, oldVal, newVal) -> {
            total.set(price * newVal.intValue());
        });
    }

    public int getProductId() { return productId; }
    public String getProductName() { return productName.get(); }
    public double getPrice() { return price.get(); }
    public int getQuantity() { return quantity.get(); }
    public double getTotal() { return total.get(); }

    public void setQuantity(int quantity) { this.quantity.set(quantity); }

    public StringProperty productNameProperty() { return productName; }
    public DoubleProperty priceProperty() { return price; }
    public IntegerProperty quantityProperty() { return quantity; }
    public DoubleProperty totalProperty() { return total; }
}
