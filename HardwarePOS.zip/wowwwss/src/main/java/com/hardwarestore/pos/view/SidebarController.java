package com.hardwarestore.pos.view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import java.util.*;
import java.util.function.Consumer;
import javafx.animation.ScaleTransition;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.util.Duration;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class SidebarController {

    @FXML public Button posButton, imsButton, cusButton, repButton, admButton, setButton;

    private String currentView;
    private Consumer<String> onViewChange;
    private String userRole = "staff"; // Default to staff to avoid null

    @FXML
    public void initialize() {
        setupButtonActions();
        setupButtonAnimations();
    }

    private void setupButtonActions() {
        posButton.setOnAction(e -> switchView("POS"));
        imsButton.setOnAction(e -> switchView("IMS"));
        cusButton.setOnAction(e -> switchView("CUS"));
        repButton.setOnAction(e -> switchView("REP"));
        admButton.setOnAction(e -> switchView("ADM"));
        setButton.setOnAction(e -> switchView("SET"));
    }

    private void switchView(String viewName) {
        // Protect staff access
        if ("staff".equalsIgnoreCase(userRole) && !"POS".equals(viewName)) {
            System.out.println("Access denied for staff to view: " + viewName);
            showAccessDeniedAlert();
            return;
        }

        currentView = viewName;
        highlightActiveButton();

        if (onViewChange != null) {
            onViewChange.accept(viewName);
        }
    }

    private void highlightActiveButton() {
        List<Button> allButtons = Arrays.asList(posButton, imsButton, cusButton, repButton, admButton, setButton);
        allButtons.forEach(btn -> btn.getStyleClass().remove("active-btn"));

        switch (currentView) {
            case "POS" -> posButton.getStyleClass().add("active-btn");
            case "IMS" -> imsButton.getStyleClass().add("active-btn");
            case "CUS" -> cusButton.getStyleClass().add("active-btn");
            case "REP" -> repButton.getStyleClass().add("active-btn");
            case "ADM" -> admButton.getStyleClass().add("active-btn");
            case "SET" -> setButton.getStyleClass().add("active-btn");
        }
    }

    public void setOnViewChange(Consumer<String> handler) {
        this.onViewChange = handler;
    }

    public String getCurrentView() {
        return currentView;
    }

    private void setupAnimatedButton(Button button) {
        DropShadow shadow = new DropShadow();

        button.addEventHandler(MouseEvent.MOUSE_ENTERED, e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(200), button);
            st.setToX(1.05);
            st.setToY(1.05);
            st.play();
            button.setEffect(shadow);
        });

        button.addEventHandler(MouseEvent.MOUSE_EXITED, e -> {
            ScaleTransition st = new ScaleTransition(Duration.millis(200), button);
            st.setToX(1);
            st.setToY(1);
            st.play();
            button.setEffect(null);
        });
    }

    private void setupButtonAnimations() {
        setupAnimatedButton(posButton);
        setupAnimatedButton(imsButton);
        setupAnimatedButton(cusButton);
        setupAnimatedButton(repButton);
        setupAnimatedButton(admButton);
        setupAnimatedButton(setButton);
    }

    public void setUserRole(String userRole) {
        this.userRole = userRole;
        System.out.println("Role received in sidebar: " + userRole);

        // Reset all buttons
        List<Button> allButtons = Arrays.asList(posButton, imsButton, cusButton, repButton, admButton, setButton);
        allButtons.forEach(btn -> btn.setDisable(false));

        if ("staff".equalsIgnoreCase(userRole)) {
            imsButton.setDisable(true);
            cusButton.setDisable(true);
            repButton.setDisable(true);
            admButton.setDisable(true);
            setButton.setDisable(true);

            if (!"POS".equals(currentView)) {
                switchView("POS");
            }
        } else if ("admin".equalsIgnoreCase(userRole)) {
            allButtons.forEach(btn -> btn.setDisable(false));
        }
    }

    public void updateSidebarForRole() {
        if ("staff".equalsIgnoreCase(userRole)) {
            imsButton.setDisable(true);
            cusButton.setDisable(true);
            repButton.setDisable(true);
            admButton.setDisable(true);
            setButton.setDisable(true);
        } else {
            imsButton.setDisable(false);
            cusButton.setDisable(false);
            repButton.setDisable(false);
            admButton.setDisable(false);
            setButton.setDisable(false);
        }
    }

    private void showAccessDeniedAlert() {
        Alert alert = new Alert(AlertType.WARNING);
        alert.setTitle("Access Denied");
        alert.setHeaderText(null);
        alert.setContentText("You do not have permission to access this section.");
        alert.showAndWait();
    }
}
