package com.hardwarestore.pos;

public class Product {
    private int id;
    private String name;
    private double price;
    private int quantity;
    private String barcode;
    private String category;     // 🆕 New
    private String imagePath;    // 🆕 New

    public Product(int id, String name, double price, int quantity, String barcode, String category, String imagePath) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.barcode = barcode;
        this.category = category;
        this.imagePath = imagePath;
    }

    // Optional constructor if barcode, category or imagePath are not needed
    public Product(int id, String name, double price, int quantity) {
        this(id, name, price, quantity, null, null, null);
    }

    // ✅ Getters
    public int getId() { return id; }
    public String getName() { return name; }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }
    public String getBarcode() { return barcode; }
    public String getCategory() { return category; }     // 🆕
    public String getImagePath() { return imagePath; }   // 🆕

    // ✅ Setters
    public void setId(int id) { this.id = id; }
    public void setName(String name) { this.name = name; }
    public void setPrice(double price) { this.price = price; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setBarcode(String barcode) { this.barcode = barcode; }
    public void setCategory(String category) { this.category = category; }     // 🆕
    public void setImagePath(String imagePath) { this.imagePath = imagePath; } // 🆕
}
