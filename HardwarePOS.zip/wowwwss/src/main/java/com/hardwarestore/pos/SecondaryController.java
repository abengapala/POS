package com.hardwarestore.pos;

import javafx.fxml.FXML;
import java.io.IOException;

public class SecondaryController {
    
    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("primary"); // Make sure "primary.fxml" exists
    }
}