package com.hardwarestore.pos;

import com.hardwarestore.pos.view.AboutDialogController;
import javafx.application.Application;
import javafx.application.HostServices;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;

public class App extends Application {

    private static Scene scene;
    private static App instance;

    public static App getInstance() {
        return instance;
    }

    @Override
    public void start(Stage stage) {
        instance = this; // Set the static reference

        try {
            // 1. Ensure necessary tables exist
            Database.createCustomersTable();
            Database.createProductsTable();

            // 2. Test database connection
            Database.testConnection();
            System.out.println("✅ Database connection successful!");

            // 3. Load the login screen
            Parent root = loadFXML("account_login");
            scene = new Scene(root);

            // 4. Apply default CSS
            URL css = App.class.getResource("/styles/fxml.css");
            if (css != null) {
                scene.getStylesheets().add(css.toExternalForm());
            } else {
                System.err.println("⚠️ Warning: /styles/fxml.css not found.");
            }

            // 5. Configure login window
            stage.setScene(scene);
            stage.setTitle("Hardware Store POS - Login");
            stage.setWidth(385);
            stage.setHeight(559);
            stage.centerOnScreen();
            stage.setResizable(false);
            stage.show();

        } catch (SQLException e) {
            System.err.println("❌ Database setup/connection failed!");
            e.printStackTrace();
            System.exit(1);
        } catch (IOException e) {
            System.err.println("❌ Failed to load FXML!");
            e.printStackTrace();
            System.exit(1);
        }
    }

    /** Helper to switch views */
    public static void setRoot(String fxml) throws IOException {
        Parent root = loadFXML(fxml);
        scene.setRoot(root);

        // Remove specific styles
        scene.getStylesheets().removeIf(s -> s.contains("rep-view.css"));

        if (fxml.equals("rep_view")) {
            URL css = App.class.getResource("/styles/rep-view.css");
            if (css != null) {
                scene.getStylesheets().add(css.toExternalForm());
            } else {
                System.err.println("⚠️ rep-view.css not found.");
            }
        }
    }

    private static Parent loadFXML(String fxml) throws IOException {
        URL fxmlUrl = App.class.getResource("/com/hardwarestore/pos/" + fxml + ".fxml");
        if (fxmlUrl == null) {
            throw new IOException("FXML file not found: " + fxml + ".fxml");
        }

        FXMLLoader loader = new FXMLLoader(fxmlUrl);
        return loader.load();
    }

    /** Opens the About Us dialog and injects HostServices */
    public static void showAboutDialog() {
        try {
            FXMLLoader loader = new FXMLLoader(App.class.getResource("/com/hardwarestore/pos/AboutDialog.fxml"));
            Parent root = loader.load();

            AboutDialogController controller = loader.getController();
            controller.setHostServices(getInstance().getHostServices());

            Stage stage = new Stage();
            stage.setTitle("About Us");
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args); // ✅ Use args for Maven exec plugin compatibility
    }
}
