package com.hardwarestore.pos;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Database {
    private static final String URL = "jdbc:mysql://localhost:3306/hardware_store?useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    // Test connection
    public static void testConnection() throws SQLException {
        try (Connection conn = getConnection()) {
            System.out.println("Database connection test: SUCCESS");
        }
    }

    // Get connection
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    
    
 // Create the new customers table
public static void createCustomersTable() throws SQLException {
    String sql = """
      CREATE TABLE IF NOT EXISTS customers (
        name          VARCHAR(100) NOT NULL,
        receipt_id    INT          NOT NULL PRIMARY KEY,
        price_total   VARCHAR(50),
        date          VARCHAR(50),
        items_ordered TEXT
      )
      """;

    try (Connection c = getConnection(); Statement s = c.createStatement()) {
      s.execute(sql);
    }
  }

  // Load all receipts
  public static ObservableList<Customer> getAllCustomers() throws SQLException {
    ObservableList<Customer> list = FXCollections.observableArrayList();
    String sql = "SELECT name, receipt_id, price_total, date, items_ordered FROM customers";

    try (Connection c = getConnection();
         Statement s = c.createStatement();
         ResultSet rs = s.executeQuery(sql)) {

      while (rs.next()) {
        list.add(new Customer(
          rs.getString("name"),
          rs.getInt("receipt_id"),       // ← renamed
          rs.getString("price_total"),
          rs.getString("date"),
          rs.getString("items_ordered")
        ));
      }
    }
    return list;
  }

  // Search by name or exact receipt_id
  public static ObservableList<Customer> searchCustomers(String term) throws SQLException {
    ObservableList<Customer> list = FXCollections.observableArrayList();
    String sql = """
      SELECT name, receipt_id, price_total, date, items_ordered
        FROM customers
       WHERE name LIKE ? OR receipt_id = ?
      """;

    try (Connection c = getConnection();
         PreparedStatement p = c.prepareStatement(sql)) {

      p.setString(1, "%" + term + "%");
      int id = term.matches("\\d+") ? Integer.parseInt(term) : -1;
      p.setInt   (2, id);

      try (ResultSet rs = p.executeQuery()) {
        while (rs.next()) {
          list.add(new Customer(
            rs.getString("name"),
            rs.getInt("receipt_id"),
            rs.getString("price_total"),
            rs.getString("date"),
            rs.getString("items_ordered")
          ));
        }
      }
    }
    return list;
  }

  // Insert new receipt
  public static boolean addCustomer(Customer c) throws SQLException {
    String sql = """
      INSERT INTO customers(name, receipt_id, price_total, date, items_ordered)
      VALUES (?, ?, ?, ?, ?)
      """;

    try (Connection conn = getConnection();
         PreparedStatement p = conn.prepareStatement(sql)) {

      p.setString(1, c.getName());
      p.setInt   (2, c.getReceiptId());     // ← correct getter
      p.setString(3, c.getPriceTotal());
      p.setString(4, c.getDate());
      p.setString(5, c.getItemsOrdered());

      return p.executeUpdate() == 1;
    }
  }

  // Update existing receipt by receipt_id
  public static boolean updateCustomer(Customer c) throws SQLException {
    String sql = """
      UPDATE customers
         SET name          = ?,
             price_total   = ?,
             date          = ?,
             items_ordered = ?
       WHERE receipt_id    = ?
      """;

    try (Connection conn = getConnection();
         PreparedStatement p = conn.prepareStatement(sql)) {

      p.setString(1, c.getName());
      p.setString(2, c.getPriceTotal());
      p.setString(3, c.getDate());
      p.setString(4, c.getItemsOrdered());
      p.setInt   (5, c.getReceiptId());     // ← correct getter

      return p.executeUpdate() == 1;
    }
  }

  // Delete by receipt_id
  public static boolean deleteCustomer(int receiptId) throws SQLException {
    String sql = "DELETE FROM customers WHERE receipt_id = ?";

    try (Connection conn = getConnection();
         PreparedStatement p = conn.prepareStatement(sql)) {

      p.setInt(1, receiptId);
      return p.executeUpdate() == 1;
    }
  }

// ================== PRODUCT OPERATIONS ================== //

// Create products table
public static void createProductsTable() throws SQLException {
    String query = "CREATE TABLE IF NOT EXISTS items (" +
                   "id INT AUTO_INCREMENT PRIMARY KEY," +
                   "name VARCHAR(100) NOT NULL," +
                   "price DECIMAL(10,2) NOT NULL," +
                   "quantity INT NOT NULL," +
                   "barcode VARCHAR(50)," +
                   "category VARCHAR(100)," +
                   "imagePath TEXT)";
    try (Connection conn = getConnection();
         Statement stmt = conn.createStatement()) {
        stmt.execute(query);
    }
}


// Get all products
public static ObservableList<Product> getAllProducts() throws SQLException {
    ObservableList<Product> products = FXCollections.observableArrayList();
    String query = "SELECT id, name, price, quantity, barcode, category, image_path FROM items";


    try (Connection conn = getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(query)) {
         
        while (rs.next()) {
         products.add(new Product(
    rs.getInt("id"),
    rs.getString("name"),
    rs.getDouble("price"),
    rs.getInt("quantity"),
    rs.getString("barcode"),
    rs.getString("category"),
    rs.getString("image_path")
));

        }
    }
    return products;
}

// Add new product
public static boolean addProduct(Product product) throws SQLException {
    String query = "INSERT INTO items (name, price, quantity, barcode, category, image_path) VALUES (?, ?, ?, ?, ?, ?)";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

        pstmt.setString(1, product.getName());
        pstmt.setDouble(2, product.getPrice());
        pstmt.setInt(3, product.getQuantity());
        pstmt.setString(4, product.getBarcode());
        pstmt.setString(5, product.getCategory());
        pstmt.setString(6, product.getImagePath());

        int affectedRows = pstmt.executeUpdate();

        if (affectedRows == 0) {
            return false;
        }

        try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
            if (generatedKeys.next()) {
                product.setId(generatedKeys.getInt(1));
            }
        }
        return true;
    }
}


// Update product
public static boolean updateProduct(Product product) throws SQLException {
    String query = "UPDATE items SET name = ?, price = ?, quantity = ?, barcode = ? WHERE id = ?";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
         
        pstmt.setString(1, product.getName());
        pstmt.setDouble(2, product.getPrice());
        pstmt.setInt(3, product.getQuantity());
        pstmt.setString(4, product.getBarcode());
        pstmt.setInt(5, product.getId());
        
        return pstmt.executeUpdate() > 0;
    }
}

// Update product quantity (for POS checkout)
public static boolean updateProductQuantity(int productId, int quantityChange) throws SQLException {
    String query = "UPDATE items SET quantity = quantity + ? WHERE id = ?";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
         
        pstmt.setInt(1, quantityChange);
        pstmt.setInt(2, productId);
        return pstmt.executeUpdate() > 0;
    }
}

// Delete product
public static boolean deleteProduct(int productId) throws SQLException {
    String query = "DELETE FROM items WHERE id = ?";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
         
        pstmt.setInt(1, productId);
        return pstmt.executeUpdate() > 0;
    }
}

// Search products by name or barcode
public static ObservableList<Product> searchProducts(String searchTerm) throws SQLException {
    ObservableList<Product> products = FXCollections.observableArrayList();
    String query = "SELECT * FROM items WHERE name LIKE ? OR barcode LIKE ?";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
         
        pstmt.setString(1, "%" + searchTerm + "%");
        pstmt.setString(2, "%" + searchTerm + "%");
        ResultSet rs = pstmt.executeQuery();
        
        while (rs.next()) {
         products.add(new Product(
    rs.getInt("id"),
    rs.getString("name"),
    rs.getDouble("price"),
    rs.getInt("quantity"),
    rs.getString("barcode"),
    rs.getString("category"),
    rs.getString("image_path")
));

        }
    }
    return products;
}

    // Check if customer exists
    public static boolean customerExists(int receiptId) throws SQLException {
  String query = "SELECT receipt_id FROM customers WHERE receipt_id = ?";
  try (Connection conn = getConnection();
       PreparedStatement pstmt = conn.prepareStatement(query)) {
    pstmt.setInt(1, receiptId);
    try (ResultSet rs = pstmt.executeQuery()) {
      return rs.next();
    }
  }
}



    public static Product getProductByBarcode(String barcode) {
    String sql = "SELECT id, name, price, quantity, barcode, category, image_path FROM items WHERE barcode = ?";

    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, barcode);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            return new Product(
                 rs.getInt("id"),
         rs.getString("name"),
        rs.getDouble("price"),
        rs.getInt("quantity"),
        rs.getString("barcode"),
        rs.getString("category"),     // 👈 make sure this column is selected in your SQL
        rs.getString("image_path")  
            );
        }

    } catch (SQLException e) {
        System.err.println("❌ Error fetching product by barcode:");
        e.printStackTrace();
    }

    return null;
}
      /** 
   * Fetches all receipts between fromDate and toDate (inclusive). 
   * Expects your `customers` table to store total_amount and vat columns.
   */
 public static ObservableList<Receipt> getReceiptsBetween(String from, String to) throws SQLException {
        ObservableList<Receipt> list = FXCollections.observableArrayList();
        String sql = """
            SELECT receipt_id, name, price_total, date
              FROM customers
             WHERE date BETWEEN ? AND ?
            """;

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, from);
            stmt.setString(2, to);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("receipt_id");
                    String name = rs.getString("name");
                    // Remove any currency symbol and parse:
                    String totalStr = rs.getString("price_total").replace("₱", "").trim();
                    double total = Double.parseDouble(totalStr);
                    double vat = total * 0.12;
                    String date = rs.getString("date");  // still in 'YYYY-MM-DD'

                    list.add(new Receipt(id, name, total, vat, date));
                }
            }
        }
        return list;
    }

   public static int getProductStock(int productId) {
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement("SELECT quantity FROM items WHERE id = ?")) {
        stmt.setInt(1, productId);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return rs.getInt("quantity");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return 0;
}

public double getTotalSales() {
    double total = 0.0;
    String sql = "SELECT SUM(total_price) FROM orders"; // Adjust table/column name if different
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        if (rs.next()) {
            total = rs.getDouble(1);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return total;
}

public int getInventoryCount() {
    int totalItems = 0;
    String sql = "SELECT SUM(quantity) FROM items";
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        if (rs.next()) {
            totalItems = rs.getInt(1);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return totalItems;
}

public int getCustomerCount() {
    int total = 0;
    String sql = "SELECT COUNT(*) FROM customers";
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        if (rs.next()) {
            total = rs.getInt(1);
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
    return total;
}

 // Create orders table
public static void createOrdersTable() throws SQLException {
    String sql = """
        CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            customer_name VARCHAR(100),
            total_price DECIMAL(10,2),
            date DATE
        )
        """;

    try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
        stmt.execute(sql);
    }
}

// Create order_items table
public static void createOrderItemsTable() throws SQLException {
    String sql = """
        CREATE TABLE IF NOT EXISTS order_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT,
            item_id INT,
            quantity INT,
            price DECIMAL(10,2),
            FOREIGN KEY (order_id) REFERENCES orders(id),
            FOREIGN KEY (item_id) REFERENCES items(id)
        )
        """;

    try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
        stmt.execute(sql);
    }
}

public static int insertOrder(String customerName, double totalPrice) throws SQLException {
    String sql = "INSERT INTO orders (customer_name, total_price, date) VALUES (?, ?, ?)";
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

        stmt.setString(1, customerName);
        stmt.setDouble(2, totalPrice);
        stmt.setDate(3, java.sql.Date.valueOf(java.time.LocalDate.now()));

        int affected = stmt.executeUpdate();
        if (affected == 0) throw new SQLException("Inserting order failed.");

        try (ResultSet rs = stmt.getGeneratedKeys()) {
            if (rs.next()) return rs.getInt(1);
            else throw new SQLException("No order ID returned.");
        }
    }
}
public static void insertOrderItem(int orderId, int itemId, int quantity, double price) throws SQLException {
    String sql = "INSERT INTO order_items (order_id, item_id, quantity, price) VALUES (?, ?, ?, ?)";
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, orderId);
        stmt.setInt(2, itemId);
        stmt.setInt(3, quantity);
        stmt.setDouble(4, price);
        stmt.executeUpdate();
    }
}

public double getTodaySales() {
    String query = "SELECT SUM(total_price) FROM orders WHERE date = CURDATE()";
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        if (rs.next()) {
            return rs.getDouble(1);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return 0.0;
}



public double getYesterdaySales() {
    String query = "SELECT SUM(total_price) FROM orders WHERE date = CURDATE() - INTERVAL 1 DAY";
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        if (rs.next()) {
            return rs.getDouble(1);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return 0.0;
}


public int getLowStockCount() {
    String query = "SELECT COUNT(*) FROM items WHERE quantity < 10";
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return 0;
}

public int getNewCustomersThisMonth() {
    String query = "SELECT COUNT(*) FROM customers WHERE MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())";
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return 0;
}
public void saveStoreInfo(String name, String address, String contact) {
    String queryCheck = "SELECT COUNT(*) FROM store_info";
    String insertQuery = "INSERT INTO store_info (name, address, contact) VALUES (?, ?, ?)";
    String updateQuery = "UPDATE store_info SET name = ?, address = ?, contact = ? WHERE id = 1";

    try (Connection conn = getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(queryCheck)) {

        rs.next();
        int count = rs.getInt(1);

        if (count == 0) {
            try (PreparedStatement pstmt = conn.prepareStatement(insertQuery)) {
                pstmt.setString(1, name);
                pstmt.setString(2, address);
                pstmt.setString(3, contact);
                pstmt.executeUpdate();
            }
        } else {
            try (PreparedStatement pstmt = conn.prepareStatement(updateQuery)) {
                pstmt.setString(1, name);
                pstmt.setString(2, address);
                pstmt.setString(3, contact);
                pstmt.executeUpdate();
            }
        }

    } catch (SQLException e) {
        e.printStackTrace();
    }
}

public String[] loadStoreInfo() {
    String[] info = new String[3];
    String query = "SELECT name, address, contact FROM store_info WHERE id = 1";

    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(query);
         ResultSet rs = stmt.executeQuery()) {

        if (rs.next()) {
            info[0] = rs.getString("name");
            info[1] = rs.getString("address");
            info[2] = rs.getString("contact");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }

    return info;
}

public String validateLogin(String username, String password) {
    String sql = "SELECT role FROM users WHERE username = ? AND password = ?";
    try (Connection conn = getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setString(1, username);
        stmt.setString(2, password);

        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return rs.getString("role");
        }
    } catch (SQLException e) {
        e.printStackTrace();
        // Optional: Show an alert or log error if needed
    }
    return null; // Ensure null is returned if no role is found
}
// Add these methods to your Database.java class

// Get all users
public static ObservableList<User> getAllUsers() throws SQLException {
    ObservableList<User> users = FXCollections.observableArrayList();
    String sql = "SELECT id, username, password, role FROM users";

    try (Connection conn = getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {

        while (rs.next()) {
            users.add(new User(
                rs.getInt("id"),
                rs.getString("username"),
                rs.getString("password"),
                rs.getString("role")
            ));
        }
    }
    return users;
}

// Add new user
public static boolean addUser(String username, String password, String role) throws SQLException {
    String sql = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, username);
        pstmt.setString(2, password); // Consider hashing the password
        pstmt.setString(3, role);

        return pstmt.executeUpdate() > 0;
    }
}

// Update existing user
public static boolean updateUser(int id, String username, String role) throws SQLException {
    String sql = "UPDATE users SET username = ?, role = ? WHERE id = ?";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, username);
        pstmt.setString(2, role);
        pstmt.setInt(3, id);

        return pstmt.executeUpdate() > 0;
    }
}

// Change user password
public static boolean changePassword(int id, String newPassword) throws SQLException {
    String sql = "UPDATE users SET password = ? WHERE id = ?";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, newPassword); // Consider hashing the password
        pstmt.setInt(2, id);

        return pstmt.executeUpdate() > 0;
    }
}

// Change password by username and old password verification
public static boolean changePassword(String username, String oldPassword, String newPassword) throws SQLException {
    String checkSql = "SELECT id FROM users WHERE username = ? AND password = ?";
    String updateSql = "UPDATE users SET password = ? WHERE id = ?";

    try (Connection conn = getConnection();
         PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {

        checkStmt.setString(1, username);
        checkStmt.setString(2, oldPassword);

        try (ResultSet rs = checkStmt.executeQuery()) {
            if (rs.next()) {
                int id = rs.getInt("id");

                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                    updateStmt.setString(1, newPassword);
                    updateStmt.setInt(2, id);
                    return updateStmt.executeUpdate() > 0;
                }
            }
        }
    }
    return false; // Password verification failed or user not found
}

// Delete user
public static boolean deleteUser(int id) throws SQLException {
    String sql = "DELETE FROM users WHERE id = ?";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setInt(1, id);
        return pstmt.executeUpdate() > 0;
    }
}

// Check if username already exists
public static boolean usernameExists(String username) throws SQLException {
    String sql = "SELECT id FROM users WHERE username = ?";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, username);
        try (ResultSet rs = pstmt.executeQuery()) {
            return rs.next();
        }
    }
}

// Check if user is admin
public static boolean isAdmin(String username) throws SQLException {
    String sql = "SELECT role FROM users WHERE username = ?";

    try (Connection conn = getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, username);
        try (ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                return "admin".equals(rs.getString("role"));
            }
            return false;
        }
    }
}

}