package com.hardwarestore.pos.view;

import com.hardwarestore.pos.Database;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.event.ActionEvent;
import javafx.scene.Node;

public class Admin_viewController {

    @FXML private Label welcomeLabel;
    @FXML private Label salesValueLabel;
    @FXML private Label inventoryValueLabel;
    @FXML private Label customerValueLabel;

    @FXML private VBox detailsBox; // This is the VBox for showing details

    @FXML
    public void initialize() {
        welcomeLabel.setText("Welcome, Admin");

        // Load data
        Database db = new Database();
        double totalSales = db.getTotalSales();
        int totalInventory = db.getInventoryCount();
        int customerCount = db.getCustomerCount();

        salesValueLabel.setText("₱" + String.format("%.2f", totalSales));
        inventoryValueLabel.setText(totalInventory + "/0"); // You can update '0' to SKU count if needed
        customerValueLabel.setText(String.valueOf(customerCount));

        // Apply admin-view.css safely
        Platform.runLater(() -> {
            Scene scene = welcomeLabel.getScene();
            if (scene != null) {
                String adminCss = getClass()
                        .getResource("/styles/admin-view.css")
                        .toExternalForm();

                // Optional: Remove other styles like rep-view.css
                scene.getStylesheets().removeIf(css -> css.contains("rep-view.css"));

                if (!scene.getStylesheets().contains(adminCss)) {
                    scene.getStylesheets().add(adminCss);
                }
            }
        });
    }

    @FXML
private void onViewSales(ActionEvent event) {
    Database db = new Database();
    double total = db.getTotalSales();
    double today = db.getTodaySales();
    double yesterday = db.getYesterdaySales();
    double change = (yesterday != 0) ? ((today - yesterday) / yesterday) * 100 : 0;

    showDetails("Sales Summary",
        "Total Sales: ₱" + String.format("%.2f", total),
        "Today's Sales: ₱" + String.format("%.2f", today),
        "Yesterday's Sales: ₱" + String.format("%.2f", yesterday),
        "Growth: " + String.format("%.2f", change) + "%"
    );
}


@FXML
private void onViewInventory(ActionEvent event) {
    Database db = new Database();
    int total = db.getInventoryCount();
    int low = db.getLowStockCount(); // e.g., quantity < 10

    showDetails("Inventory Summary",
        "Items in Stock: " + total,
        "Low Stock Items: " + low
    );
}

@FXML
private void onViewCustomers(ActionEvent event) {
    Database db = new Database();
    int total = db.getCustomerCount();
    int newThisMonth = db.getNewCustomersThisMonth();

    showDetails("Customer Summary",
        "Total Registered: " + total,
        "New This Month: " + newThisMonth
    );
}

    @FXML
    private void onLogout(ActionEvent event) {
        System.out.println("Logout clicked");
        // TODO: implement logout navigation
    }

    @FXML
    private void hideDetails(ActionEvent event) {
        detailsBox.setVisible(false);
        detailsBox.setManaged(false);
        detailsBox.getChildren().removeIf(node -> node instanceof Label); // Clear dynamic content
    }

    private void showDetails(String title, String... lines) {
    detailsBox.setVisible(true);
    detailsBox.setManaged(true);
    detailsBox.getChildren().clear();

    Label titleLabel = new Label(title);
    titleLabel.getStyleClass().add("detail-title");

    VBox contentBox = new VBox(5);
    contentBox.getStyleClass().add("detail-content-box");

    for (String line : lines) {
        Label info = new Label(line);
        info.getStyleClass().add("detail-line");
        contentBox.getChildren().add(info);
    }

    Button closeBtn = new Button("Close");
    closeBtn.setOnAction(e -> hideDetails(null));
    closeBtn.getStyleClass().add("card-button");

    detailsBox.getChildren().addAll(titleLabel, contentBox, closeBtn);
}

}
