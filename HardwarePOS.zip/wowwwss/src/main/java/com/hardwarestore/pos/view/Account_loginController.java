package com.hardwarestore.pos.view;

import com.hardwarestore.pos.Database;
import com.hardwarestore.pos.PrimaryController;
import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.util.Duration;
import java.io.IOException;

public class Account_loginController {
    @FXML private TextField accountIdField;
    @FXML private PasswordField passwordField;
    
    // Declare the role variable at the class level
    private String role;
    
    @FXML
    private void initialize() {
        // Optional setup if needed
    }
    
    @FXML
    private void handleLogin() {
        String enteredId = accountIdField.getText().trim();
        String enteredPassword = passwordField.getText().trim();
        
        if (enteredId.isEmpty() || enteredPassword.isEmpty()) {
            showAlert("Login Error", "Please enter both ID and password.");
            return;
        }
        
        Database db = new Database();
        // Debugging output to see the role value
        System.out.println("Attempting login with ID: " + enteredId + " and Password: " + enteredPassword);
        
        // Get the role from DB
        role = db.validateLogin(enteredId, enteredPassword);
        
        // Check if role is null or invalid
        if (role == null) {
            showAlert("Login Failed", "Username or Password is not correct.");
            return;
        }
        
        // Print out role for debugging purposes
        System.out.println("Login successful! Role: " + role);
        
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/hardwarestore/pos/primary.fxml"));
            Parent posRoot = loader.load();
            PrimaryController controller = loader.getController();
            
            // Check if role is valid before passing it to PrimaryController
            if (role != null) {
                controller.setUserRole(role);  // Pass role to PrimaryController
            } else {
                showAlert("Login Failed", "Role is not assigned properly.");
                return;
            }
            
            Stage stage = (Stage) accountIdField.getScene().getWindow();
            Scene scene = new Scene(posRoot);
            
            // Apply styles
            scene.getStylesheets().clear();
            scene.getStylesheets().addAll(
                getClass().getResource("/styles/fxml.css").toExternalForm(),
                getClass().getResource("/styles/sidebar.css").toExternalForm()
            );
            
            stage.setScene(scene);
            stage.setFullScreen(true);
            stage.setFullScreenExitHint("");
            stage.setFullScreenExitKeyCombination(javafx.scene.input.KeyCombination.NO_MATCH);
            
            // ✅ Force loading the sidebar after scene set
            controller.loadSidebar();  // <<---- VERY IMPORTANT
            
            // Fade transition
            posRoot.setOpacity(0);
            FadeTransition fadeIn = new FadeTransition(Duration.millis(500), posRoot);
            fadeIn.setFromValue(0);
            fadeIn.setToValue(1);
            fadeIn.play();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Failed to load main POS UI.");
        }
    }
    
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}