package com.hardwarestore.pos.view;

import com.hardwarestore.pos.Database;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.sql.SQLException;
import java.util.Optional;

public class ChangePasswordDialog extends Dialog<ButtonType> {

    private final TextField usernameField;
    private final PasswordField currentPasswordField;
    private final PasswordField newPasswordField;
    private final PasswordField confirmPasswordField;

    public ChangePasswordDialog(String currentUsername) {
        setTitle("Change Password");
        setHeaderText("Enter current and new password");

        // Set buttons
        ButtonType changeButtonType = new ButtonType("Change", ButtonBar.ButtonData.OK_DONE);
        getDialogPane().getButtonTypes().addAll(changeButtonType, ButtonType.CANCEL);

        // Create the grid layout
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        usernameField = new TextField(currentUsername);
        usernameField.setDisable(true); // Username cannot be changed
        currentPasswordField = new PasswordField();
        newPasswordField = new PasswordField();
        confirmPasswordField = new PasswordField();

        grid.add(new Label("Username:"), 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(new Label("Current Password:"), 0, 1);
        grid.add(currentPasswordField, 1, 1);
        grid.add(new Label("New Password:"), 0, 2);
        grid.add(newPasswordField, 1, 2);
        grid.add(new Label("Confirm Password:"), 0, 3);
        grid.add(confirmPasswordField, 1, 3);

        getDialogPane().setContent(grid);

        // Request focus on the current password field
        currentPasswordField.requestFocus();

        // Validate the input before closing the dialog
        Button changeButton = (Button) getDialogPane().lookupButton(changeButtonType);
        changeButton.setOnAction(event -> {
            // Consume the event to prevent the dialog from closing
            event.consume();
            
            // Check if the fields are empty
            if (currentPasswordField.getText().isEmpty() || 
                newPasswordField.getText().isEmpty() || 
                confirmPasswordField.getText().isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "All fields are required");
                return;
            }
            
            // Check if the new passwords match
            if (!newPasswordField.getText().equals(confirmPasswordField.getText())) {
                showAlert(Alert.AlertType.ERROR, "New passwords do not match");
                return;
            }
            
            try {
                // Try to change the password
                if (Database.changePassword(usernameField.getText(), 
                                            currentPasswordField.getText(),
                                            newPasswordField.getText())) {
                    // Success
                    showAlert(Alert.AlertType.INFORMATION, "Password changed successfully");
                    // Now we can close the dialog
                    setResult(changeButtonType);
                    close();
                } else {
                    // Failed validation
                    showAlert(Alert.AlertType.ERROR, "Current password is incorrect");
                }
            } catch (SQLException e) {
                showAlert(Alert.AlertType.ERROR, "Database error: " + e.getMessage());
                e.printStackTrace();
            }
        });
    }
    
    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(type == Alert.AlertType.INFORMATION ? "Success" : "Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}