package com.hardwarestore.pos.view;

import com.hardwarestore.pos.Database;
import com.hardwarestore.pos.Product;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import com.hardwarestore.pos.util.Toast;
import java.util.Optional;
import java.util.function.Consumer;


public class IMSController {

    @FXML private TableView<Product> inventoryTable;
    @FXML private TableColumn<Product, String> itemNameColumn;
    @FXML private TableColumn<Product, String> barcodeColumn;
    @FXML private TableColumn<Product, Integer> quantityColumn;
    @FXML private TableColumn<Product, Double> priceColumn;
    @FXML private TableColumn<Product, String> categoryColumn;
    @FXML private TableColumn<Product, Void> actionColumn;

    @FXML private TextField searchField;
    @FXML private Button addItemButton;

    @FXML
   
public void initialize() {
    // Set up table columns
    itemNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
    barcodeColumn.setCellValueFactory(new PropertyValueFactory<>("barcode"));
    quantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
    priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
    categoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
    inventoryTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

    // ✅ Add this line to load the external CSS
inventoryTable.getStylesheets().add(getClass().getResource("/styles/TableStyle.css").toExternalForm());

    loadInventoryItems();
    setupActionColumn();

    searchField.textProperty().addListener((obs, oldText, newText) -> {
        if (newText.trim().isEmpty()) {
            loadInventoryItems();
        } else {
            searchItems();
        }
    });
}


    private void loadInventoryItems() {
        try {
            ObservableList<Product> products = Database.getAllProducts();
            inventoryTable.setItems(products);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void searchItems() {
        String term = searchField.getText().trim();
        if (term.isEmpty()) {
            loadInventoryItems();
            return;
        }

        try {
            ObservableList<Product> products = Database.searchProducts(term);
            inventoryTable.setItems(products);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void setupActionColumn() {
        actionColumn.setCellFactory(col -> new TableCell<>() {
            private final Button editButton = new Button("Edit");
            private final Button deleteButton = new Button("Delete");
            {
                editButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white;");
                deleteButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
                editButton.setOnAction(event -> {
                    Product product = getTableView().getItems().get(getIndex());
                    handleEdit(product);
                });
                deleteButton.setOnAction(event -> {
                    Product product = getTableView().getItems().get(getIndex());
                    handleDelete(product);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox buttons = new HBox(5, editButton, deleteButton);
                    setGraphic(buttons);
                }
            }
        });
    }

         private void handleEdit(Product product) {
      openAddEditPopup(product);
    }
         @FXML
private void handleAddItem() {
    openAddEditPopup(null); // Passing null means it's an "Add", not an "Edit"
}


 private void handleDelete(Product product) {
    Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
    confirm.setTitle("Confirm Delete");
    confirm.setHeaderText(null);
    confirm.setContentText("Are you sure you want to delete \"" + product.getName() + "\"?");
    
    Optional<ButtonType> result = confirm.showAndWait();
    if (result.isPresent() && result.get() == ButtonType.OK) {
        try {
            if (Database.deleteProduct(product.getId())) {
                inventoryTable.getItems().remove(product);
                System.out.println("Deleted: " + product.getName());

                // ✅ Show toast after successful deletion
                Stage mainStage = (Stage) addItemButton.getScene().getWindow();
                Toast.show(mainStage, "Item deleted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

    private Consumer<String> onSuccessMessage;

public void setOnSuccessMessage(Consumer<String> onSuccessMessage) {
    this.onSuccessMessage = onSuccessMessage;
}

  private void openAddEditPopup(Product productToEdit) {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/hardwarestore/pos/add_edit_item.fxml"));
        Parent root = loader.load();

        AddEditItemController controller = loader.getController();
        controller.setProduct(productToEdit);
        controller.setOnSaveCallback(this::loadInventoryItems); // Refresh table after saving

        Stage stage = new Stage();
        stage.setTitle(productToEdit == null ? "Add Item" : "Edit Item");
        stage.setScene(new Scene(root));
        stage.initModality(Modality.APPLICATION_MODAL);

     controller.setOnSuccessMessage(message -> {
    // Show toast on the IMS main window, not the popup
    Stage mainStage = (Stage) addItemButton.getScene().getWindow();
    Toast.show(mainStage, message);
});




        stage.show();
    } catch (Exception e) {
        e.printStackTrace();
    }
    
}



}

