package com.hardwarestore.pos.view;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.application.HostServices;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class AboutDialogController implements Initializable {

    @FXML private ImageView leaderImage;
    @FXML private Label leaderNameLabel;
    @FXML private FlowPane membersFlowPane;
    @FXML private Hyperlink leaderFbLink;
    @FXML private Label leaderContributionLabel;
    @FXML private ImageView teacherImage;
    @FXML private Hyperlink teacherEmailLink;

    private HostServices hostServices;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        loadLeader();
        loadMembers();
        loadTeacher();
    }

    // Load leader profile details
    private void loadLeader() {
        String name = "Justin Edward Tecson";
        String contribution = "System Architect & Project Documentation Lead";
        String imagePath = "/com/hardwarestore/pos/images/tecson.png";

        // Set Facebook link
        leaderFbLink.setOnAction(e -> hostServices.showDocument("https://www.facebook.com/justinedwardkino.amansec"));

        // Set leader image
        setImage(leaderImage, imagePath, 180, 180);
        leaderNameLabel.setText(name);
        leaderContributionLabel.setText("Contribution: " + contribution);
        leaderContributionLabel.setStyle("-fx-font-style: italic; -fx-text-fill: gray; -fx-font-size: 16px;");
    }

    // Load team members' profiles
    private void loadMembers() {
        List<Member> members = List.of(
            new Member("Alexus C. Alcover", "Documentation: Literature & References", "/com/hardwarestore/pos/images/alcover.png", "https://www.facebook.com/alexus.alcover#"),
            new Member("Ryan Capilitan", "System Development Support", "/com/hardwarestore/pos/images/capilitan.png", "https://www.facebook.com/ryan.o.capilitan"),
            new Member("Ishia Mae Torres", "Documentation: Fishbone Diagram", "/com/hardwarestore/pos/images/torres.png", "https://www.facebook.com/ishiahmae#"),
            new Member("Jam Rovic Balorio", "Backend Development", "/com/hardwarestore/pos/images/balorio1.png", "https://www.facebook.com/jamrovic.balorioii"),
            new Member("Alberto A. Eder II", "System Development", "/com/hardwarestore/pos/images/Alberto.png", "https://www.facebook.com/silverians21"),
            new Member("Arjay Comia", "Documentation: Methodology", "/com/hardwarestore/pos/images/comia.png", "https://www.facebook.com/baka.mana.7#")
        );

        for (Member member : members) {
            membersFlowPane.getChildren().add(createMemberProfile(member));
        }
    }

    // Create a profile for each member
    private VBox createMemberProfile(Member m) {
        Image image = new Image(getClass().getResourceAsStream(m.imagePath()), 160, 160, false, false);
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(160);
        imageView.setFitHeight(160);

        // Clip to circle and apply shadow
        Circle clip = new Circle(80, 80, 80);
        imageView.setClip(clip);
        applyShadowEffect(imageView);
        addHoverAnimation(imageView);

        // Name and role labels
        Label nameLabel = new Label(m.name());
        nameLabel.setStyle("-fx-font-weight: bold; -fx-font-size: 14px;");
        Label roleLabel = new Label("Contribution: " + m.contribution());
        roleLabel.setStyle("-fx-font-style: italic; -fx-text-fill: gray; -fx-font-size: 14px;");

        // Facebook hyperlink
        Hyperlink fbLink = new Hyperlink("Facebook");
        fbLink.setOnAction(e -> hostServices.showDocument(m.facebookUrl()));

        // Profile box styling
        VBox box = new VBox(8, imageView, nameLabel, roleLabel, fbLink);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(10));
        box.setStyle("-fx-background-color: #ffffff; -fx-background-radius: 10; -fx-border-radius: 10; -fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 10, 0.3, 0, 4);");

        return box;
    }

    // Close the dialog
    @FXML
    private void onClose() {
        Stage stage = (Stage) leaderImage.getScene().getWindow();
        stage.close();
    }

    // Apply hover effect to images
    private void addHoverAnimation(ImageView imageView) {
        imageView.setOnMouseEntered(e -> {
            imageView.setScaleX(1.1);
            imageView.setScaleY(1.1);
        });
        imageView.setOnMouseExited(e -> {
            imageView.setScaleX(1.0);
            imageView.setScaleY(1.0);
        });
    }

    // Set HostServices
    public void setHostServices(HostServices hostServices) {
        this.hostServices = hostServices;
    }

    // Load teacher's profile
    private void loadTeacher() {
        String imagePath = "/com/hardwarestore/pos/images/teachers1.png";
        setImage(teacherImage, imagePath, 180, 180);

        // Apply shadow and hover effects
        applyShadowEffect(teacherImage);
        addHoverAnimation(teacherImage);

        // Set teacher's email link
        teacherEmailLink.setOnAction(e -> hostServices.showDocument("mailto:manuelluisconahadelossantos@gmail.com"));
    }

    // Helper method to set image properties (size, clip, shadow, etc.)
    private void setImage(ImageView imageView, String imagePath, double width, double height) {
        Image image = new Image(getClass().getResourceAsStream(imagePath), width, height, false, false);
        imageView.setImage(image);
        imageView.setFitWidth(width);
        imageView.setFitHeight(height);

        // Clip the image to a circle
        Circle clip = new Circle(width / 2, height / 2, width / 2);
        imageView.setClip(clip);
    }

    // Apply shadow effect to ImageViews
    private void applyShadowEffect(ImageView imageView) {
        DropShadow shadow = new DropShadow();
        shadow.setRadius(10);
        shadow.setOffsetX(0);
        shadow.setOffsetY(0);
        shadow.setColor(Color.rgb(0, 0, 0, 0.25));
        imageView.setEffect(shadow);
    }

    // Member class to hold profile data
    private record Member(String name, String contribution, String imagePath, String facebookUrl) {}
}
