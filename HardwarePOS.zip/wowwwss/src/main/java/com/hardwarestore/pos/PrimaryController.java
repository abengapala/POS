package com.hardwarestore.pos;

import com.hardwarestore.pos.view.SidebarController;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PrimaryController {

    @FXML private VBox sidebarPlaceholder;
    @FXML private BorderPane rootPane;
    @FXML private Label dateLabel;
    @FXML private Label timeLabel;
    @FXML private Button logoutButton;
    @FXML private StackPane centerContent;
    @FXML private Label storeNameLabel;

    private final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    private final DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh:mm a");
    private String currentView = "";
    private String userRole = "staff";

public void initialize() {
    rootPane.sceneProperty().addListener((obs, oldScene, newScene) -> {
        if (newScene != null) {
            Stage stage = (Stage) newScene.getWindow();
            if (stage != null) {
                configureFullscreen(stage);
            } else {
                System.err.println("Stage is null.");
            }
        }
    });

    updateDateTime();
    startClock();
    setupLogoutHandler();
    loadSidebar();
}



    private void configureFullscreen(Stage stage) {
        stage.setFullScreen(true);
        stage.setFullScreenExitHint("");
        stage.setFullScreenExitKeyCombination(KeyCombination.NO_MATCH);
        
        // Optional: ESC key to exit fullscreen (remove if not needed)
        rootPane.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ESCAPE) {
                stage.setFullScreen(false);
            }
        });
    }

public void setUserRole(String role) {
    if (role != null) {
        this.userRole = role;
        storeNameLabel.setText("SHIERLY AND JOSH HARDWARE TRADING - " + role.toUpperCase());
        handleViewChange("POS"); // Default to POS view after login
    } else {
        // Handle invalid role case
        showAlert("Login Failed", "Invalid role assigned.");
    }
}


    private void updateDateTime() {
        LocalDateTime now = LocalDateTime.now();
        dateLabel.setText(now.format(dateFormatter));
        timeLabel.setText(now.format(timeFormatter));
    }

    private void startClock() {
        Timeline clock = new Timeline(
            new KeyFrame(Duration.ZERO, e -> updateDateTime()),
            new KeyFrame(Duration.seconds(60))
        );
        clock.setCycleCount(Animation.INDEFINITE);
        clock.play();
    }

    private void setupLogoutHandler() {
        logoutButton.setOnAction(e -> logout());
    }

public void loadSidebar() {
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/hardwarestore/pos/sidebar.fxml"));
        VBox sidebar = loader.load();

        SidebarController sidebarController = loader.getController();
        sidebarController.setOnViewChange(this::handleViewChange);
        sidebarController.setUserRole(userRole);  // Pass the role here
        
        // Ensure the sidebar is updated when the role changes
        sidebarController.updateSidebarForRole();

        sidebarPlaceholder.getChildren().setAll(sidebar);
    } catch (IOException e) {
        System.err.println("Failed to load sidebar: " + e.getMessage());
    }
}



private void handleViewChange(String viewName) {
    // Skip if already on this view
    if (viewName.equals(currentView)) return;

    // Role-based access control
    if (!"POS".equals(viewName) && !"admin".equalsIgnoreCase(userRole)) {
        System.out.println("Access denied for " + viewName + " with role " + userRole);
        showAlert("Access Denied", "Admin privileges required");
        return;
    }

    try {
        String fxmlPath = "/com/hardwarestore/pos/" + viewName.toLowerCase() + "_view.fxml";
        Parent view = FXMLLoader.load(getClass().getResource(fxmlPath));
        
        centerContent.getChildren().setAll(view);
        currentView = viewName;
        
        System.out.println("Successfully loaded view: " + viewName);
    } catch (IOException e) {
        System.err.println("Failed to load view: " + viewName);
        e.printStackTrace();
        showAlert("Error", "Failed to load " + viewName + " view");
    }
}



  private void logout() {
    try {
        Stage stage = (Stage) rootPane.getScene().getWindow();
        Parent loginRoot = FXMLLoader.load(getClass().getResource("/com/hardwarestore/pos/account_login.fxml"));
        Scene scene = new Scene(loginRoot);

        // 🔧 Restore original size of login screen (from FXML)
        stage.setFullScreen(false);
        stage.setResizable(false); // prevent stretching
        stage.setScene(scene);
        stage.setWidth(385);       // 👈 matches StackPane prefWidth
        stage.setHeight(559);      // 👈 matches StackPane prefHeight
        stage.centerOnScreen();

        // 🎨 Reload login screen styling
        scene.getStylesheets().clear();
        scene.getStylesheets().add(getClass().getResource("/styles/fxml.css").toExternalForm());

    } catch (IOException e) {
        System.err.println("Failed to logout: " + e.getMessage());
    }
}


   private void showAlert(String title, String message) {
    Alert alert = new Alert(AlertType.WARNING);
    alert.setTitle(title);
    alert.setHeaderText(null);  // No header text
    alert.setContentText(message);  // Set the content message

    // Show the alert and wait for the user to click a button
    alert.showAndWait();
}
}