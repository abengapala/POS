package com.hardwarestore.pos.view;

import com.hardwarestore.pos.Database;
import com.hardwarestore.pos.Product;
import java.util.function.Consumer;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.collections.FXCollections;

public class AddEditItemController {

    @FXML private TextField nameField, barcodeField, quantityField, priceField;
    @FXML private Button saveButton, cancelButton;
    @FXML private ComboBox<String> categoryComboBox;

    private Product productToEdit;
    private Runnable onSaveCallback;

    public void setProduct(Product product) {
        this.productToEdit = product;
        if (product != null) {
            nameField.setText(product.getName());
            barcodeField.setText(product.getBarcode());
            quantityField.setText(String.valueOf(product.getQuantity()));
            priceField.setText(String.valueOf(product.getPrice()));
            categoryComboBox.setValue(product.getCategory());  // Set category for editing
        }
    }

    public void setOnSaveCallback(Runnable callback) {
        this.onSaveCallback = callback;
    }

    @FXML
    public void initialize() {
        // Set the available categories for the ComboBox
        categoryComboBox.setItems(FXCollections.observableArrayList(
            "Paint", "Cement", "Wood","Metal", "Sand", "Pipes",  "Tools"
        ));

        saveButton.setOnAction(e -> saveProduct());
        cancelButton.setOnAction(e -> closeWindow());
    }

   private void saveProduct() {
    try {
        String name = nameField.getText().trim();
        String barcode = barcodeField.getText().trim();
        int quantity = Integer.parseInt(quantityField.getText().trim());
        double price = Double.parseDouble(priceField.getText().trim());
        String category = categoryComboBox.getValue();  // Get selected category from ComboBox

        if (category == null || category.isEmpty()) {
            showAlert("Error", "Please select a category.");
            return;
        }

        boolean isEdit = (productToEdit != null);

        if (!isEdit) {
            // New product
            Product newProduct = new Product(0, name, price, quantity, barcode, category, null);
            Database.addProduct(newProduct);
        } else {
            // Editing product
            productToEdit.setName(name);
            productToEdit.setBarcode(barcode);
            productToEdit.setQuantity(quantity);
            productToEdit.setPrice(price);
            productToEdit.setCategory(category);
            Database.updateProduct(productToEdit);
        }

        // ✅ Call the toast callback here
        if (onSuccessMessage != null) {
            onSuccessMessage.accept(isEdit ? "Item updated successfully!" : "Item added successfully!");
        }

        if (onSaveCallback != null) onSaveCallback.run();
        closeWindow();

    } catch (Exception e) {
        e.printStackTrace();
        showAlert("Error", "Please fill in valid item data.");
    }
}


    private void closeWindow() {
        ((Stage) saveButton.getScene().getWindow()).close();
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setContentText(msg);
        alert.showAndWait();
    }
    private Consumer<String> onSuccessMessage;

public void setOnSuccessMessage(Consumer<String> onSuccessMessage) {
    this.onSuccessMessage = onSuccessMessage;
}

}
