package com.hardwarestore.pos.view;

import com.hardwarestore.pos.Customer;
import com.hardwarestore.pos.Database;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.OverrunStyle;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;

public class Cus_viewController {

    @FXML private TableView<Customer> customerTable;
    @FXML private TableColumn<Customer, String> nameColumn;
    @FXML private TableColumn<Customer, Integer> receiptIdColumn;
    @FXML private TableColumn<Customer, String> totalColumn;
    @FXML private TableColumn<Customer, String> dateColumn;
    @FXML private TableColumn<Customer, String> itemsColumn;
    @FXML private TableColumn<Customer, Void> actionsColumn;

    @FXML private TextField searchField;
    @FXML private Button searchButton;
    @FXML private Button addButton;

    @FXML private Label countLabel;
    @FXML private Label perHourLabel;
    @FXML private Label perDayLabel;
    @FXML private Label perMonthLabel;

    @FXML
    public void initialize() {
        setupTableColumns();
        setupCustomerFeatures();
        loadData();
    }

    private void setupTableColumns() {
        // bind properties
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        receiptIdColumn.setCellValueFactory(new PropertyValueFactory<>("receiptId"));
        totalColumn.setCellValueFactory(new PropertyValueFactory<>("priceTotal"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        itemsColumn.setCellValueFactory(new PropertyValueFactory<>("itemsOrdered"));

        // truncate long item lists, show full on hover
        itemsColumn.setCellFactory(col -> new TableCell<Customer,String>() {
            private final Label label = new Label();
            private final Tooltip tip = new Tooltip();

            {
                label.setTextOverrun(OverrunStyle.ELLIPSIS);
                label.setMaxWidth(col.getPrefWidth() - 10);
                Tooltip.install(label, tip);
            }

            @Override
            protected void updateItem(String items, boolean empty) {
                super.updateItem(items, empty);
                if (empty || items == null) {
                    setGraphic(null);
                } else {
                    label.setText(items);
                    tip.setText(items);
                    setGraphic(label);
                }
            }
        });

        // delete button only
        actionsColumn.setCellFactory(tv -> new TableCell<>() {
            private final Button deleteBtn = new Button("Delete");

            {
                deleteBtn.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-background-radius: 5;");
                deleteBtn.setOnAction(e -> {
                    Customer c = getTableView().getItems().get(getIndex());
                    handleDeleteCustomer(c);
                });
            }

            @Override
            protected void updateItem(Void v, boolean empty) {
                super.updateItem(v, empty);
                setGraphic(empty ? null : deleteBtn);
            }
        });
    }

    private void setupCustomerFeatures() {
        addButton.setOnAction(e -> handleAddCustomer());
        searchButton.setOnAction(e -> handleSearch());
        searchField.textProperty().addListener((obs, old, nxt) -> {
            if (nxt.isEmpty()) loadData();
            else handleSearch();
        });
    }

    private void loadData() {
        try {
            ObservableList<Customer> data = Database.getAllCustomers();
            customerTable.setItems(data);
            updateStats(data.size());
        } catch (SQLException ex) {
            showError("Load Error", ex.getMessage());
        }
    }

    private void handleSearch() {
        try {
            String term = searchField.getText().trim();
            ObservableList<Customer> results = Database.searchCustomers(term);
            customerTable.setItems(results);
            updateStats(results.size());
        } catch (SQLException ex) {
            showError("Search Error", ex.getMessage());
        }
    }

    private void handleAddCustomer() {
        // your add‑dialog logic…
    }

    private void handleDeleteCustomer(Customer c) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
            "Delete receipt “" + c.getReceiptId() + "” for " + c.getName() + "?",
            ButtonType.YES, ButtonType.NO);

        if (confirm.showAndWait().orElse(ButtonType.NO) == ButtonType.YES) {
            try {
                if (Database.deleteCustomer(c.getReceiptId())) loadData();
                else showError("Delete Error", "No row deleted.");
            } catch (SQLException ex) {
                showError("Delete Error", ex.getMessage());
            }
        }
    }

    private void updateStats(int total) {
        countLabel.setText("Receipt Count: " + total);
        perHourLabel.setText("Per Hour: " + (total/8));
        perDayLabel.setText("Per Day: " + total);
        perMonthLabel.setText("Per Month: " + (total*20));
    }

    private void showError(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        a.setHeaderText(title);
        a.showAndWait();
    }
}