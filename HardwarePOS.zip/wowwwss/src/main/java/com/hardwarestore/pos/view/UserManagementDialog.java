package com.hardwarestore.pos.view;

import com.hardwarestore.pos.Database;
import com.hardwarestore.pos.User;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.Optional;

public class UserManagementDialog extends Dialog<ButtonType> {

    private TableView<User> userTable;
    private ObservableList<User> userList;

    public UserManagementDialog() {
        setTitle("User Management");
        setHeaderText("Add, edit or remove users");

        // Set up the buttons
        getDialogPane().getButtonTypes().addAll(ButtonType.CLOSE);

        // Create table
        userTable = createUserTable();
        
        // Load users
        loadUsers();

        // Create button bar
        HBox buttonBar = createButtonBar();

        // Main layout
        VBox layout = new VBox(10, userTable, buttonBar);
        layout.setPadding(new Insets(10));
        layout.setPrefWidth(600);
        layout.setPrefHeight(500);

        getDialogPane().setContent(layout);
    }

    private TableView<User> createUserTable() {
        TableView<User> table = new TableView<>();
        
        TableColumn<User, Number> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(cellData -> cellData.getValue().idProperty());
        idColumn.setPrefWidth(50);
        
        TableColumn<User, String> usernameColumn = new TableColumn<>("Username");
        usernameColumn.setCellValueFactory(cellData -> cellData.getValue().usernameProperty());
        usernameColumn.setPrefWidth(150);
        
        TableColumn<User, String> roleColumn = new TableColumn<>("Role");
        roleColumn.setCellValueFactory(cellData -> cellData.getValue().roleProperty());
        roleColumn.setPrefWidth(100);

        table.getColumns().addAll(idColumn, usernameColumn, roleColumn);
        
        VBox.setVgrow(table, Priority.ALWAYS);
        return table;
    }

    private HBox createButtonBar() {
        Button addButton = new Button("Add User");
        addButton.setOnAction(event -> showAddUserDialog());
        
        Button editButton = new Button("Edit User");
        editButton.setOnAction(event -> {
            User selectedUser = userTable.getSelectionModel().getSelectedItem();
            if (selectedUser != null) {
                showEditUserDialog(selectedUser);
            } else {
                showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a user to edit.");
            }
        });
        
        Button deleteButton = new Button("Delete User");
        deleteButton.setOnAction(event -> {
            User selectedUser = userTable.getSelectionModel().getSelectedItem();
            if (selectedUser != null) {
                deleteUser(selectedUser);
            } else {
                showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a user to delete.");
            }
        });

        Button resetPasswordButton = new Button("Reset Password");
        resetPasswordButton.setOnAction(event -> {
            User selectedUser = userTable.getSelectionModel().getSelectedItem();
            if (selectedUser != null) {
                showResetPasswordDialog(selectedUser);
            } else {
                showAlert(Alert.AlertType.WARNING, "No Selection", "Please select a user to reset password.");
            }
        });
        
        HBox buttonBar = new HBox(10, addButton, editButton, deleteButton, resetPasswordButton);
        return buttonBar;
    }

    private void loadUsers() {
        try {
            userList = Database.getAllUsers();
            userTable.setItems(userList);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to load users: " + e.getMessage());
        }
    }

    private void showAddUserDialog() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Add New User");
        dialog.setHeaderText("Enter user details");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField usernameField = new TextField();
        PasswordField passwordField = new PasswordField();
        ComboBox<String> roleComboBox = new ComboBox<>();
        roleComboBox.getItems().addAll("admin", "staff");
        roleComboBox.setValue("staff");

        grid.add(new Label("Username:"), 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(new Label("Password:"), 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(new Label("Role:"), 0, 2);
        grid.add(roleComboBox, 1, 2);

        dialog.getDialogPane().setContent(grid);

        // Request focus on the username field by default
        usernameField.requestFocus();

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            String username = usernameField.getText().trim();
            String password = passwordField.getText();
            String role = roleComboBox.getValue();

            if (username.isEmpty() || password.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Invalid Input", "Username and password cannot be empty.");
                return;
            }

            try {
                if (Database.usernameExists(username)) {
                    showAlert(Alert.AlertType.ERROR, "Username Exists", "This username is already taken.");
                    return;
                }

                if (Database.addUser(username, password, role)) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "User added successfully.");
                    loadUsers();
                } else {
                    showAlert(Alert.AlertType.ERROR, "Failed", "Failed to add user.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to add user: " + e.getMessage());
            }
        }
    }

    private void showEditUserDialog(User user) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Edit User");
        dialog.setHeaderText("Edit user details");
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField usernameField = new TextField(user.getUsername());
        ComboBox<String> roleComboBox = new ComboBox<>();
        roleComboBox.getItems().addAll("admin", "staff");
        roleComboBox.setValue(user.getRole());

        grid.add(new Label("Username:"), 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(new Label("Role:"), 0, 1);
        grid.add(roleComboBox, 1, 1);

        dialog.getDialogPane().setContent(grid);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            String username = usernameField.getText().trim();
            String role = roleComboBox.getValue();

            if (username.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Invalid Input", "Username cannot be empty.");
                return;
            }

            try {
                if (!username.equals(user.getUsername()) && Database.usernameExists(username)) {
                    showAlert(Alert.AlertType.ERROR, "Username Exists", "This username is already taken.");
                    return;
                }

                if (Database.updateUser(user.getId(), username, role)) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "User updated successfully.");
                    loadUsers();
                } else {
                    showAlert(Alert.AlertType.ERROR, "Failed", "Failed to update user.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to update user: " + e.getMessage());
            }
        }
    }

    private void showResetPasswordDialog(User user) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("Reset Password");
        dialog.setHeaderText("Reset password for " + user.getUsername());
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        PasswordField newPasswordField = new PasswordField();
        PasswordField confirmPasswordField = new PasswordField();

        grid.add(new Label("New Password:"), 0, 0);
        grid.add(newPasswordField, 1, 0);
        grid.add(new Label("Confirm Password:"), 0, 1);
        grid.add(confirmPasswordField, 1, 1);

        dialog.getDialogPane().setContent(grid);

        Optional<ButtonType> result = dialog.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            String newPassword = newPasswordField.getText();
            String confirmPassword = confirmPasswordField.getText();

            if (newPassword.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Invalid Input", "Password cannot be empty.");
                return;
            }

            if (!newPassword.equals(confirmPassword)) {
                showAlert(Alert.AlertType.ERROR, "Password Mismatch", "Passwords do not match.");
                return;
            }

            try {
                if (Database.changePassword(user.getId(), newPassword)) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Password reset successfully.");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Failed", "Failed to reset password.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to reset password: " + e.getMessage());
            }
        }
    }

    private void deleteUser(User user) {
        Alert confirmation = new Alert(Alert.AlertType.CONFIRMATION);
        confirmation.setTitle("Confirm Delete");
        confirmation.setHeaderText("Delete User");
        confirmation.setContentText("Are you sure you want to delete user: " + user.getUsername() + "?");

        Optional<ButtonType> result = confirmation.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                if (Database.deleteUser(user.getId())) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "User deleted successfully.");
                    loadUsers();
                } else {
                    showAlert(Alert.AlertType.ERROR, "Failed", "Failed to delete user.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showAlert(Alert.AlertType.ERROR, "Database Error", "Failed to delete user: " + e.getMessage());
            }
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}