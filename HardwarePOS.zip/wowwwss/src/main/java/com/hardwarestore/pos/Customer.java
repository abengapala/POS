package com.hardwarestore.pos;

import javafx.beans.property.*;

public class Customer {
    private final StringProperty name;
    private final IntegerProperty receiptId;
    private final StringProperty priceTotal;
    private final StringProperty date;
    private final StringProperty itemsOrdered;

    public Customer(String name,
                    int receiptId,
                    String priceTotal,
                    String date,
                    String itemsOrdered) {
        this.name         = new SimpleStringProperty(name);
        this.receiptId    = new SimpleIntegerProperty(receiptId);
        this.priceTotal   = new SimpleStringProperty(priceTotal);
        this.date         = new SimpleStringProperty(date);
        this.itemsOrdered = new SimpleStringProperty(itemsOrdered);
    }

    // Getters
    public String getName()          { return name.get(); }
    public int    getReceiptId()     { return receiptId.get(); }
    public String getPriceTotal()    { return priceTotal.get(); }
    public String getDate()          { return date.get(); }
    public String getItemsOrdered()  { return itemsOrdered.get(); }

    // Setters
    public void setName(String v)          { name.set(v); }
    public void setReceiptId(int v)        { receiptId.set(v); }
    public void setPriceTotal(String v)    { priceTotal.set(v); }
    public void setDate(String v)          { date.set(v); }
    public void setItemsOrdered(String v)  { itemsOrdered.set(v); }

    // Properties for TableView binding
    public StringProperty nameProperty()          { return name; }
    public IntegerProperty receiptIdProperty()    { return receiptId; }
    public StringProperty priceTotalProperty()    { return priceTotal; }
    public StringProperty dateProperty()          { return date; }
    public StringProperty itemsOrderedProperty()  { return itemsOrdered; }
}
