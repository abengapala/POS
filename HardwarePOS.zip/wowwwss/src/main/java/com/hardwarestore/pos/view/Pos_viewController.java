package com.hardwarestore.pos.view;

import com.hardwarestore.pos.CartItem;
import com.hardwarestore.pos.Customer;
import com.hardwarestore.pos.Database;
import com.hardwarestore.pos.Product;
import java.io.IOException;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.beans.property.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableCell;
import javafx.scene.control.TextField;

import javafx.geometry.Insets;
import javafx.scene.control.Separator;
import javafx.scene.image.ImageView;
import javafx.print.PrinterJob;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javafx.geometry.HPos;
import javafx.print.PageLayout;
import javafx.print.PageOrientation;
import javafx.print.Paper;
import javafx.print.Printer;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.transform.Scale;
import javafx.scene.input.KeyCode;
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamLockException;
import com.github.sarxos.webcam.WebcamPanel;
import com.google.zxing.*;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;

import javax.swing.*;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import javafx.application.Platform;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.IntegerStringConverter;



public class Pos_viewController {

    @FXML private TilePane productGrid;
    @FXML private TableView<CartItem> cartTable;
    @FXML private TableColumn<CartItem, String> productColumn;
    @FXML private TableColumn<CartItem, Double> priceColumn;
    @FXML private TableColumn<CartItem, Integer> qtyColumn;
    @FXML private TableColumn<CartItem, Double> totalColumn;
    @FXML private Label totalLabel;
    @FXML private TextField barcodeField;
@FXML
private void filterMetal() {
    filterByCategory("Metal");
}

@FXML
private void filterPaint() {
    filterByCategory("Paint");
}

@FXML
private void filterWood() {
    filterByCategory("Wood");
}

@FXML
private void filterCement() {
    filterByCategory("Cement");
}

@FXML
private void filterTools() {
    filterByCategory("Tools");
}

@FXML
private void filterSand() {
    filterByCategory("Sand");
}

@FXML
private void filterAll() throws SQLException {
    loadProductsFromDatabase(); // Assuming this loads all categories
}
@FXML
private void filterPipes() {
    filterByCategory("Pipes");
}
@FXML
private TableColumn<CartItem, Void> deleteColumn;

@FXML
private TextField customerNameField;


@FXML private Label subtotalLabel;
@FXML private Label vatLabel;
@FXML private TextField cashField;
@FXML private Label changeLabel;
    @FXML
    
private void handleBarcodeSearch() {
    String barcode = barcodeField.getText().trim();
    if (!barcode.isEmpty()) {
        Product product = Database.getProductByBarcode(barcode);
        if (product != null) {
            addToCart(product); // 🔄 add to cart instead of showing card
        } else {
            new Alert(Alert.AlertType.INFORMATION, "No product found with barcode: " + barcode).showAndWait();
        }
        barcodeField.clear();
        Platform.runLater(() -> barcodeField.requestFocus());
    }
}

@FXML
private void openScannerCamera(javafx.event.ActionEvent event) {
    Webcam webcam = Webcam.getDefault();
    if (webcam == null) {
        System.out.println("No webcam detected!");
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Webcam Error");
        alert.setHeaderText("No Webcam Found");
        alert.setContentText("Please connect a webcam to use the scanner.");
        alert.showAndWait();
        return;
    }

    try {
        if (webcam.isOpen()) {
            System.out.println("Webcam already open. Closing before reopening...");
            webcam.close();
        }

        webcam.setViewSize(new Dimension(640, 480));
        webcam.open(); // 🧠 May throw if locked by another app or not released properly

    } catch (WebcamLockException e) {
        System.err.println("❌ Webcam is locked by another process or was not released properly.");
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Webcam Locked");
        alert.setHeaderText("Camera in Use");
        alert.setContentText("The webcam is already in use or wasn't released properly.\nPlease close any other app using the camera and try again.");
        alert.showAndWait();
        return;
    }

    WebcamPanel panel = new WebcamPanel(webcam);
    panel.setFPSDisplayed(true);

    JFrame window = new JFrame("Scanner Camera");
    window.add(panel);
    window.setResizable(true);
    window.pack();
    window.setVisible(true);
    window.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    // Ensure webcam is released when window is closed manually
    window.addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowClosing(java.awt.event.WindowEvent e) {
            webcam.close();
        }
    });

    // Barcode scanning thread
    Executor executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r);
        t.setDaemon(true);
        return t;
    });

    executor.execute(() -> {
        do {
            try {
                BufferedImage image = webcam.getImage();
                if (image == null) continue;

                LuminanceSource source = new BufferedImageLuminanceSource(image);
                BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

                Result result;
                try {
                    result = new MultiFormatReader().decode(bitmap);
                } catch (NotFoundException e) {
                    continue; // no barcode in this frame
                }

                if (result != null) {
                    System.out.println("Scanned barcode: " + result.getText());
                    javafx.application.Platform.runLater(() -> {
                        barcodeField.setText(result.getText());
                        handleBarcodeSearch();
                        window.dispose();
                        webcam.close();
                    });
                    break;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } while (true);
    });
}





private final ObservableList<CartItem> cartItems = FXCollections.observableArrayList();
private double totalAmount = 0.0;


    private static final Map<String, String> PRODUCT_IMAGES = new HashMap<>();
    static {
        PRODUCT_IMAGES.put("Hammer", "/com/hardwarestore/pos/images/Hammer.png");
        PRODUCT_IMAGES.put("Nails", "/com/hardwarestore/pos/images/Nails.jpg");
        PRODUCT_IMAGES.put("Screwdriver", "/com/hardwarestore/pos/images/Screwdriver.jpg");
    }

     public void initialize() {
    System.out.println("🛒 Initializing POSController...");
    
    
    barcodeField.setOnAction(event -> {
        handleBarcodeSearch();
    });
    
  
    barcodeField.setOnKeyPressed(event -> {
        if (event.getCode() == KeyCode.ENTER) {
            handleBarcodeSearch();
        }
    });
    
    setupCartTable();
    try {
        loadProducts();
    } catch (Exception e) {
        System.err.println("❌ Error during POS init:");
        e.printStackTrace();
    }
    
  
    Platform.runLater(() -> barcodeField.requestFocus());
}


   private void loadProducts() {
    try (Connection conn = Database.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery("SELECT id, name, price, quantity, barcode, category, image_path FROM items")) {

        System.out.println("✅ Connected to DB, loading items...");
        while (rs.next()) {
            Product product = new Product(
        rs.getInt("id"),
        rs.getString("name"),
        rs.getDouble("price"),
        rs.getInt("quantity"),
        rs.getString("barcode"),
        rs.getString("category"),     // 👈 make sure this column is selected in your SQL
        rs.getString("image_path")     // 👈 same here
);

            createProductCard(product);
        }
    } catch (SQLException e) {
        System.err.println("❌ Database error while loading products:");
        e.printStackTrace();
    }
}


    private void createProductCard(Product product) {
    VBox card = new VBox(8);
    card.getStyleClass().add("product-card");
    card.setAlignment(Pos.CENTER);
    card.setPadding(new Insets(10));
    card.setPrefSize(160, 200);

    ImageView imageView = new ImageView();
try {
    Image img;
    if (product.getImagePath() != null && !product.getImagePath().isEmpty()) {
        img = new Image(getClass().getResourceAsStream(product.getImagePath()));
        if (img.isError() || img.getWidth() == 0) throw new IllegalArgumentException("Invalid image");
    } else {
        // Use lightweight online placeholder
        img = new Image("https://via.placeholder.com/120x120.png?text=No+Image");
    }
    imageView.setImage(img);
} catch (Exception e) {
    System.err.println("⚠️ Error loading image for: " + product.getName() + " — using web placeholder.");
    imageView.setImage(new Image("https://via.placeholder.com/120x120.png?text=No+Image"));
}


    imageView.setFitWidth(120);
    imageView.setFitHeight(120);
    imageView.setPreserveRatio(true);

    Label nameLabel = new Label(product.getName());
    nameLabel.setStyle("-fx-font-weight: bold;");

    Label priceLabel = new Label(String.format("₱%.2f", product.getPrice()));
    Label stockLabel = new Label("In stock: " + product.getQuantity());

    // 👉 Barcode label
    Label barcodeLabel = new Label("Barcode: " + (product.getBarcode() != null ? product.getBarcode() : "N/A"));
    barcodeLabel.setStyle("-fx-font-size: 11; -fx-text-fill: #666;");

  Button addButton = new Button();
addButton.setMaxWidth(Double.MAX_VALUE);

if (product.getQuantity() <= 0) {
    addButton.setText("Out of Stock");
    addButton.setDisable(true);
    addButton.setStyle(
        "-fx-background-color: #cccccc; " +
        "-fx-text-fill: #666666; " +
        "-fx-font-style: italic; " +
        "-fx-opacity: 0.7;"
    );
} else {
    addButton.setText("Add to Cart");
    addButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white;");
    addButton.setOnAction(e -> addToCart(product));
}


    // 👉 Add barcodeLabel before or after the stockLabel
    card.getChildren().addAll(imageView, nameLabel, priceLabel, stockLabel, barcodeLabel, addButton);
    productGrid.getChildren().add(card);
}


private void addToCart(Product product) {
    if (product.getQuantity() <= 0) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Out of Stock");
        alert.setHeaderText("Item not available");
        alert.setContentText("The item \"" + product.getName() + "\" is currently out of stock.");
        alert.showAndWait();
        return;
    }

    CartItem existing = cartItems.stream()
        .filter(item -> item.getProductId() == product.getId())
        .findFirst()
        .orElse(null);

    if (existing != null) {
        if (existing.getQuantity() < product.getQuantity()) {
            existing.setQuantity(existing.getQuantity() + 1);
        } else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Stock Limit Reached");
            alert.setHeaderText("Cannot add more");
            alert.setContentText("You’ve already added the maximum available stock for \"" + product.getName() + "\".");
            alert.showAndWait();
        }
    } else {
        cartItems.add(new CartItem(
            product.getId(),
            product.getName(),
            product.getPrice(),
            1
        ));
    }

    updateTotal();
}


private void updateTotal() {
    totalAmount = cartItems.stream()
        .mapToDouble(CartItem::getTotal)
        .sum();

    double vat = totalAmount * 0.12;
    double subtotal = totalAmount - vat;

    subtotalLabel.setText(String.format("Subtotal: ₱%.2f", subtotal));
    vatLabel.setText(String.format("VAT (12%%): ₱%.2f", vat));
    totalLabel.setText(String.format("TOTAL: ₱%.2f", totalAmount));
}



@FXML
private void handleCheckout() {
    if (cartItems.isEmpty()) {
        new Alert(Alert.AlertType.WARNING,
            "Please add items to the cart before proceeding to checkout.",
            ButtonType.OK).showAndWait();
        return;
    }

    // 1) Parse cash input
    double cash;
    try {
        cash = Double.parseDouble(cashField.getText().trim());
    } catch (NumberFormatException e) {
        new Alert(Alert.AlertType.ERROR,
            "Please enter a valid number in the Cash field.",
            ButtonType.OK).showAndWait();
        return;
    }

    // 2) Check sufficient cash
    if (cash < totalAmount) {
        new Alert(Alert.AlertType.WARNING,
            String.format("Cash entered: ₱%.2f\nTotal: ₱%.2f", cash, totalAmount),
            ButtonType.OK).showAndWait();
        return;
    }

    // 3) Compute change and update UI
    double change = cash - totalAmount;
    changeLabel.setText(String.format("Change: ₱%.2f", change));

    // 4) Update stock in DB
    try (Connection conn = Database.getConnection();
         Statement stmt = conn.createStatement()) {
        for (CartItem item : cartItems) {
            stmt.executeUpdate(String.format(
                "UPDATE items SET quantity = quantity - %d WHERE id = %d",
                item.getQuantity(), item.getProductId()));
        }
    } catch (SQLException e) {
        e.printStackTrace();
        new Alert(Alert.AlertType.ERROR,
            "Failed to update item quantities.\n" + e.getMessage(),
            ButtonType.OK).showAndWait();
        return;
    }

    // 5) Record receipt in DB
    int receiptId = (int)(System.currentTimeMillis() / 1000);
    StringBuilder itemsOrdered = new StringBuilder();
    for (CartItem item : cartItems) {
        itemsOrdered.append(item.getProductName())
                    .append(" x").append(item.getQuantity())
                    .append("; ");
    }

   boolean inserted = false;
String customerName = customerNameField.getText().trim().isEmpty()
    ? "Walk-in Customer"
    : customerNameField.getText().trim();

try {
    // ✅ Insert into `orders` and get the new order ID
    int orderId = Database.insertOrder(customerName, totalAmount);

    // ✅ Insert each cart item into `order_items`
    for (CartItem item : cartItems) {
        Database.insertOrderItem(orderId, item.getProductId(), item.getQuantity(), item.getPrice());
    }

    inserted = true;

    // 🧪 OPTIONAL: keep inserting into customers for now so Cus_viewController works
    Database.addCustomer(new Customer(
        customerName,
        orderId, // using order ID as receipt ID
        String.format("₱%.2f", totalAmount),
        LocalDate.now().toString(),
        itemsOrdered.toString()
    ));

} catch (SQLException ex) {
    ex.printStackTrace();
    inserted = false;
}


    if (!inserted) {
        new Alert(Alert.AlertType.ERROR,
            "Order could not be saved to the database.",
            ButtonType.OK).showAndWait();
        return;
    }

    // 6) Build & preview/print receipt (now passing receiptId)
    double vat      = totalAmount * 0.12;
    double subtotal = totalAmount - vat;
    VBox receiptNode = buildReceiptNode(
        customerNameField.getText().trim().isEmpty()
            ? "Walk-in Customer"
            : customerNameField.getText().trim(),
        subtotal,
        vat,
        totalAmount,
        cash,
        change,
        List.copyOf(cartItems),
        receiptId         // ← here!
    );
    showReceiptPreview(receiptNode);

    // 7) Clear cart & reset fields
    cartItems.clear();
    updateTotal();
    cashField.clear();
    customerNameField.clear();
    changeLabel.setText("Change: ₱0.00");
}





private void showReceiptPreview(VBox receiptNode) {
    // Wrap it in a ScrollPane in case it’s tall
    ScrollPane scroll = new ScrollPane(receiptNode);
    scroll.setFitToWidth(true);
    scroll.setPrefViewportWidth(Region.USE_COMPUTED_SIZE);
    scroll.setPrefViewportHeight(Region.USE_COMPUTED_SIZE);

    // Create a new window (modal)
    Stage previewStage = new Stage();
    previewStage.initOwner(cartTable.getScene().getWindow());
    previewStage.initModality(Modality.APPLICATION_MODAL);
    previewStage.setTitle("Receipt Preview");

    // Add “Print” and “Close” buttons
    Button printBtn = new Button("Print");
    Button closeBtn = new Button("Close");
    HBox buttons = new HBox(10, printBtn, closeBtn);
    buttons.setAlignment(Pos.CENTER);
    buttons.setPadding(new Insets(10));

    VBox root = new VBox(10, scroll, buttons);
    root.setPadding(new Insets(10));
    Scene scene = new Scene(root);
    previewStage.setScene(scene);

    // Wire the buttons
    printBtn.setOnAction(e -> {
        printReceipt(receiptNode);
        previewStage.close();
    });
    closeBtn.setOnAction(e -> previewStage.close());

    previewStage.showAndWait();
}



private void setupCartTable() {
    cartTable.setEditable(true); // ✅ Make table editable

    productColumn.setCellValueFactory(cell -> cell.getValue().productNameProperty());
    priceColumn.setCellValueFactory(cell -> cell.getValue().priceProperty().asObject());
    qtyColumn.setCellValueFactory(cell -> cell.getValue().quantityProperty().asObject());
    totalColumn.setCellValueFactory(cell -> cell.getValue().totalProperty().asObject());

    // ✅ Allow inline editing of quantity
    qtyColumn.setCellFactory(TextFieldTableCell.<CartItem, Integer>forTableColumn(new IntegerStringConverter()));
    qtyColumn.setOnEditCommit(event -> {
        CartItem item = event.getRowValue();
        int newQty = event.getNewValue();

        if (newQty <= 0) {
            new Alert(Alert.AlertType.WARNING, "Quantity must be at least 1.").showAndWait();
            cartTable.refresh();
            return;
        }

        int stockAvailable = Database.getProductStock(item.getProductId()); // You must add this method to Database.java
        if (newQty > stockAvailable) {
            new Alert(Alert.AlertType.WARNING,
                "Only " + stockAvailable + " units available in stock.")
                .showAndWait();
            cartTable.refresh();
            return;
        }

        item.setQuantity(newQty);
        updateTotal();
    });

    // ✅ Delete button column
    deleteColumn.setCellFactory(col -> new TableCell<CartItem, Void>() {
        private final Button deleteBtn = new Button("❌");

        {
            deleteBtn.setStyle("-fx-background-color: transparent; -fx-font-size: 14;");
            deleteBtn.setOnAction(e -> {
                CartItem item = getTableView().getItems().get(getIndex());
                cartItems.remove(item);
                updateTotal();
            });
        }

        @Override
        protected void updateItem(Void item, boolean empty) {
            super.updateItem(item, empty);
            setGraphic(empty ? null : deleteBtn);
        }
    });

    cartTable.setItems(cartItems);
}


  /**
 * Builds a VBox node containing your branded receipt.
 */

private VBox buildReceiptNode(String customerName,
                            double subtotal,
                            double vat,
                            double totalAmount,
                            double cash,
                            double change,
                            List<CartItem> items,
                            int receiptId) {

    // Base font size configuration
    final double tableFontSize = 14;  // Increased from 12
    final double totalsFontSize = 14; // Increased from 12
    final double totalAmountFontSize = 16; // Larger for emphasis
    final double paymentFontSize = 14; // Increased from 12

    // ─── BASE CONTAINER ──────────────────────────────────────
    VBox root = new VBox(16);
    root.setPadding(new Insets(24));
    root.setStyle("""
        -fx-background-color: white;
        -fx-font-family: 'Segoe UI', sans-serif;
        -fx-font-size: 14px;
        -fx-text-fill: #333333;
    """);

    // ─── HEADER ──────────────────────────────────────────────
    Label storeName = new Label("SHIERLY JOSH HARDWARE TRADING");
    storeName.setStyle("""
        -fx-font-size: 22px;
        -fx-font-weight: bold;
    """);

    Label storeAddr = new Label("115 Major Marcos St. Area 2 Veterans Village, Pasong Tamo, Quezon City");
    storeAddr.setStyle("""
        -fx-font-size: 14px;
        -fx-font-weight: bold;
        -fx-text-fill: #444444;
    """);

    ImageView logo = new ImageView(new Image(
        getClass().getResourceAsStream("/com/hardwarestore/pos/images/logo.jpg")));
    logo.setFitWidth(160);
    logo.setPreserveRatio(true);

    Label receiptNum = new Label("Receipt # " + receiptId);
    receiptNum.setStyle("""
        -fx-font-size: 12px;
        -fx-font-weight: bold;
        -fx-text-fill: #2E7D32;
    """);

    HBox header = new HBox(32,
        new VBox(4, storeName, storeAddr),
        new VBox(6, receiptNum, logo)
    );
    header.setAlignment(Pos.CENTER_LEFT);
    HBox.setHgrow(header.getChildren().get(0), Priority.ALWAYS);
    root.getChildren().add(header);

    // ─── TITLE ───────────────────────────────────────────────
    Label title = new Label("RECEIPT");
    title.setStyle("""
        -fx-font-size: 28px;
        -fx-font-weight: bold;
        -fx-text-fill: #2E7D32;
    """);
    title.setAlignment(Pos.CENTER);
    title.setMaxWidth(Double.MAX_VALUE);
    root.getChildren().add(title);

    // ─── CUSTOMER INFO ───────────────────────────────────────
    Label billedTo = new Label("Billed To");
    billedTo.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #2E7D32;");

    Label customerLbl = new Label(customerName);
    customerLbl.setStyle("-fx-font-size: 14px;");

    Label dateLbl = new Label("Date: " + LocalDate.now().format(DateTimeFormatter.ofPattern("MM-dd-yyyy")));
    dateLbl.setStyle("-fx-font-size: 14px; -fx-text-fill: #666666;");

    HBox info = new HBox(80,
        new VBox(2, billedTo, customerLbl),
        new VBox(2, dateLbl)
    );
    root.getChildren().add(info);

    // ─── ITEMS TABLE (with larger font) ──────────────────────
    GridPane table = new GridPane();
    table.setHgap(12);
    table.setVgap(8);
    table.getColumnConstraints().addAll(
        new ColumnConstraints(70),   // QTY (slightly wider)
        new ColumnConstraints(300),  // Description
        new ColumnConstraints(100),  // Unit Price (wider)
        new ColumnConstraints(100)    // Amount (wider)
    );

    // headers with larger font
    String[] hdrs = {"QTY", "Description", "Unit Price", "Amount"};
    for (int i = 0; i < hdrs.length; i++) {
        Label h = new Label(hdrs[i]);
        h.setStyle(String.format("""
            -fx-font-size: %fpx;
            -fx-font-weight: bold;
            -fx-background-color: #E8F5E9;
            -fx-padding: 8 10;
        """, tableFontSize));
        // Right-align price columns
        if (i >= 2) {
            h.setAlignment(Pos.CENTER_RIGHT);
        }
        table.add(h, i, 0);
    }

    // data rows with larger font
    int row = 1;
    for (CartItem it : items) {
        Label qty = new Label(String.format("%.2f", (double)it.getQuantity()));
        Label desc = new Label(it.getProductName());
        Label unit = new Label(String.format("₱%.2f", it.getPrice()));
        Label amt = new Label(String.format("₱%.2f", it.getTotal()));

        // right-align numeric columns
        qty.setAlignment(Pos.CENTER_RIGHT);
        unit.setAlignment(Pos.CENTER_RIGHT);
        amt.setAlignment(Pos.CENTER_RIGHT);

        // Set styles with larger font
        String cellStyle = String.format("-fx-font-size: %fpx; -fx-padding: 0 8 0 0;", tableFontSize);
        unit.setStyle(cellStyle);
        amt.setStyle(cellStyle);
        qty.setStyle(cellStyle);
        desc.setStyle(String.format("-fx-font-size: %fpx;", tableFontSize));

        table.add(qty, 0, row);
        table.add(desc, 1, row);
        table.add(unit, 2, row);
        table.add(amt, 3, row);
        row++;
    }

    // Divider line
    Label divider = new Label();
    divider.setMinHeight(1);
    divider.setMaxWidth(Double.MAX_VALUE);
    divider.setStyle("-fx-background-color: #DDDDDD;");
    table.add(divider, 0, row, 4, 1);
    row++;

    root.getChildren().add(table);

    // ─── TOTALS SECTION (with larger font) ───────────────────
    GridPane totals = new GridPane();
    totals.setHgap(10);
    totals.setVgap(8);  // Increased gap
    totals.getColumnConstraints().addAll(
        new ColumnConstraints(70),
        new ColumnConstraints(300),
        new ColumnConstraints(100),
        new ColumnConstraints(100)
    );

    // Subtotal
    Label subLbl = new Label("Subtotal:");
    Label subVal = new Label(String.format("₱%.2f", subtotal));
    subLbl.setAlignment(Pos.CENTER_RIGHT);
    subVal.setAlignment(Pos.CENTER_RIGHT);
    subLbl.setStyle(String.format("-fx-font-size: %fpx;", totalsFontSize));
    subVal.setStyle(String.format("-fx-font-size: %fpx; -fx-padding: 0 8 0 0;", totalsFontSize));
    totals.add(subLbl, 2, 0);
    totals.add(subVal, 3, 0);

    // VAT
    Label vatLbl = new Label("VAT (12%):");
    Label vatVal = new Label(String.format("₱%.2f", vat));
    vatLbl.setAlignment(Pos.CENTER_RIGHT);
    vatVal.setAlignment(Pos.CENTER_RIGHT);
    vatLbl.setStyle(String.format("-fx-font-size: %fpx;", totalsFontSize));
    vatVal.setStyle(String.format("-fx-font-size: %fpx; -fx-padding: 0 8 0 0;", totalsFontSize));
    totals.add(vatLbl, 2, 1);
    totals.add(vatVal, 3, 1);

    // Total Amount - with larger emphasized font
    Label totalLbl = new Label("TOTAL:");
    Label totalVal = new Label(String.format("₱%.2f", totalAmount));
    totalLbl.setAlignment(Pos.CENTER_RIGHT);
    totalVal.setAlignment(Pos.CENTER_RIGHT);
    totalLbl.setStyle(String.format("-fx-font-size: %fpx; -fx-font-weight: bold;", totalAmountFontSize));
    totalVal.setStyle(String.format("-fx-font-size: %fpx; -fx-font-weight: bold; -fx-padding: 0 8 0 0;", totalAmountFontSize));
    totals.add(totalLbl, 2, 2);
    totals.add(totalVal, 3, 2);

    root.getChildren().add(totals);

    // ─── PAYMENT INFO (with larger font) ─────────────────────
    Label cashLbl = new Label("Cash:   ₱" + String.format("%.2f", cash));
    Label changeLbl = new Label("Change: ₱" + String.format("%.2f", change));
    cashLbl.setStyle(String.format("-fx-font-size: %fpx; -fx-padding: 0 8 0 0;", paymentFontSize));
    changeLbl.setStyle(String.format("-fx-font-size: %fpx; -fx-padding: 0 8 0 0;", paymentFontSize));
    cashLbl.setAlignment(Pos.CENTER_RIGHT);
    changeLbl.setAlignment(Pos.CENTER_RIGHT);

    VBox paymentBox = new VBox(6, cashLbl, changeLbl);  // Increased gap
    paymentBox.setAlignment(Pos.CENTER_RIGHT);
    paymentBox.setMaxWidth(Double.MAX_VALUE);
    HBox.setHgrow(paymentBox, Priority.ALWAYS);

    // Separator
    Separator sep = new Separator();
    sep.setPadding(new Insets(8, 0, 8, 0));  // Added padding

    // Footer with larger font
    Label thanks = new Label("Thank you for your buying! Come Again!!");
    thanks.setStyle(String.format("-fx-font-size: %fpx; -fx-font-style: italic;", paymentFontSize));

    root.getChildren().addAll(sep, paymentBox, thanks);

    return root;
}





/** Sends the given node to the printer. */
private void printReceipt(VBox receiptNode) {
    PrinterJob job = PrinterJob.createPrinterJob();
    if (job == null) return;

    // Show the system Print dialog
    if (job.showPrintDialog(receiptNode.getScene().getWindow())) {
        Printer printer = job.getPrinter();
        // 1) Pick your paper and orientation - e.g. Landscape Letter
        PageLayout pageLayout = printer.createPageLayout(
            Paper.NA_LETTER,                  // or Paper.A4, or your custom form
            PageOrientation.PORTRAIT,
            Printer.MarginType.DEFAULT        // or NO_MARGINS on a roll printer
        );
        job.getJobSettings().setPageLayout(pageLayout);

        // 2) Figure out how big your receipt-node really is on screen
        double nodeWidth  = receiptNode.getBoundsInParent().getWidth();
        double nodeHeight = receiptNode.getBoundsInParent().getHeight();

        // 3) Figure out the printable area
        double printableWidth  = pageLayout.getPrintableWidth();
        double printableHeight = pageLayout.getPrintableHeight();

        // 4) Compute a uniform scale so the node fits the printable area
        double scaleX = printableWidth  / nodeWidth;
        double scaleY = printableHeight / nodeHeight;
        double scale  = Math.min(scaleX, scaleY);

        // 5) Apply the scale transform to your node
        receiptNode.getTransforms().add(new Scale(scale, scale));

        // 6) Print at that scale
        boolean success = job.printPage(receiptNode);

        // 7) Clean up the transform so it doesn’t affect future uses
        receiptNode.getTransforms().clear();

        if (success) {
            job.endJob();
        } else {
            System.err.println("Printing failed");
        }
    }
}



   private void filterByCategory(String category) {
    productGrid.getChildren().clear();
    try (Connection conn = Database.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(
             "SELECT id, name, price, quantity, barcode, category, image_path FROM items WHERE category = '" + category + "'")) {

        while (rs.next()) {
            Product product = new Product(
                rs.getInt("id"),
                rs.getString("name"),
                rs.getDouble("price"),
                rs.getInt("quantity"),
                rs.getString("barcode"),
                rs.getString("category"),
                rs.getString("image_path")
            );
            createProductCard(product);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

   private void loadProductsFromDatabase() throws SQLException {
    productGrid.getChildren().clear(); // Clear old product cards

    List<Product> products = Database.getAllProducts(); // Your DB helper method

    for (Product product : products) {
        createProductCard(product); // Reuse your method to show each product
    }
}

}

    

