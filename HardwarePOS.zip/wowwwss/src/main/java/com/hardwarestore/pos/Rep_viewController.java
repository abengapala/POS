package com.hardwarestore.pos;

import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.print.PrinterJob;
import javafx.scene.layout.BorderPane;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;

public class Rep_viewController {

    @FXML private DatePicker fromDatePicker;
    @FXML private DatePicker toDatePicker;

    @FXML private Label totalCountLabel;
    @FXML private Label grossSalesLabel;
    @FXML private Label vatCollectedLabel;
    @FXML private Label avgSaleLabel;

    @FXML private Button filterButton;
    @FXML private Button exportCsvButton;
    @FXML private Button printReportButton;

    @FXML
    public void initialize() {
        // ─────── Defer CSS loading until after this view is in a Scene ───────
        Platform.runLater(() -> {
            Scene scene = totalCountLabel.getScene();
            if (scene != null) {
                String repCss = getClass()
                    .getResource("/styles/rep-view.css")
                    .toExternalForm();
                      scene.getStylesheets().removeIf(css -> css.contains("admin-view.css"));
                if (!scene.getStylesheets().contains(repCss)) {
                    scene.getStylesheets().add(repCss);
                }
            }
            
        });
        // ──────────────────────────────────────────────────────────────────────

        // default both pickers to today
        LocalDate today = LocalDate.now();
        fromDatePicker.setValue(today);
        toDatePicker.setValue(today);

        // initial load
        updateSummary(today, today);
    }

    @FXML
    private void onFilter(ActionEvent event) {
        LocalDate from = fromDatePicker.getValue();
        LocalDate to   = toDatePicker.getValue();
        if (from == null || to == null || to.isBefore(from)) {
            new Alert(Alert.AlertType.WARNING,
                "Please select a valid date range.",
                ButtonType.OK).showAndWait();
            return;
        }
        updateSummary(from, to);
    }

    private void updateSummary(LocalDate from, LocalDate to) {
        try {
            ObservableList<Receipt> receipts =
                Database.getReceiptsBetween(from.toString(), to.toString());

            int count = receipts.size();
            double gross = receipts.stream()
                                   .mapToDouble(Receipt::getTotalAmount)
                                   .sum();
            double vat   = receipts.stream()
                                   .mapToDouble(Receipt::getVat)
                                   .sum();
            double avg   = count > 0 ? gross / count : 0.0;

            totalCountLabel   .setText(String.valueOf(count));
            grossSalesLabel   .setText(String.format("₱%.2f", gross));
            vatCollectedLabel .setText(String.format("₱%.2f", vat));
            avgSaleLabel      .setText(String.format("₱%.2f", avg));

        } catch (SQLException ex) {
            new Alert(Alert.AlertType.ERROR,
                "Failed to load report:\n" + ex.getMessage(),
                ButtonType.OK).showAndWait();
        }
    }

    @FXML
    private void onExportCsv(ActionEvent event) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Save Report as CSV");
        chooser.getExtensionFilters()
               .add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        chooser.setInitialFileName("sales-report.csv");

        File file = chooser.showSaveDialog(filterButton.getScene().getWindow());
        if (file == null) return;

        try {
            LocalDate from = fromDatePicker.getValue();
            LocalDate to   = toDatePicker.getValue();
            ObservableList<Receipt> receipts =
                Database.getReceiptsBetween(from.toString(), to.toString());

            try (PrintWriter pw = new PrintWriter(file)) {
                pw.println("Date,Receipt ID,Total Amount,VAT Collected");
                for (Receipt r : receipts) {
                    pw.printf("%s,%d,%.2f,%.2f%n",
                              r.getDate(),
                              r.getReceiptId(),
                              r.getTotalAmount(),
                              r.getVat());
                }
            }

            new Alert(Alert.AlertType.INFORMATION,
                "CSV exported to:\n" + file.getAbsolutePath(),
                ButtonType.OK).showAndWait();

        } catch (SQLException | FileNotFoundException ex) {
            new Alert(Alert.AlertType.ERROR,
                "Failed to export CSV:\n" + ex.getMessage(),
                ButtonType.OK).showAndWait();
        }
    }

    @FXML
    private void onPrintReport(ActionEvent event) {
        PrinterJob job = PrinterJob.createPrinterJob();
        if (job == null) {
            new Alert(Alert.AlertType.ERROR,
                "No printers available.",
                ButtonType.OK).showAndWait();
            return;
        }

        boolean proceed = job.showPrintDialog(printReportButton
                                               .getScene()
                                               .getWindow());
        if (!proceed) {
            job.endJob();
            return;
        }

        BorderPane reportPane =
            (BorderPane) totalCountLabel.getScene().getRoot();
        boolean printed = job.printPage(reportPane);
        if (printed) {
            job.endJob();
        } else {
            new Alert(Alert.AlertType.ERROR,
                "Failed to print report.",
                ButtonType.OK).showAndWait();
        }
    }
}
