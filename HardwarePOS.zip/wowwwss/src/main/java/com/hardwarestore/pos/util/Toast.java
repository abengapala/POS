package com.hardwarestore.pos.util;

import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Window;
import javafx.util.Duration;

public class Toast {

    public static void show(Window ownerWindow, String message) {
        Scene scene = ownerWindow.getScene();
        if (scene == null) return;

        // Try to use existing StackPane or wrap the root in one
        Pane originalRoot = (Pane) scene.getRoot();
        StackPane toastLayer;

        if (originalRoot instanceof StackPane) {
            toastLayer = (StackPane) originalRoot;
        } else {
            // Wrap in a new StackPane if needed
            toastLayer = new StackPane();
            toastLayer.getChildren().add(originalRoot);
            scene.setRoot(toastLayer);
        }

        Label toast = new Label(message);
        toast.setStyle("-fx-background-color: rgba(0, 0, 0, 0.85); -fx-text-fill: white; "
                     + "-fx-padding: 10px 16px; -fx-background-radius: 6px; -fx-font-size: 14px;");
        toast.setOpacity(0);

        toastLayer.getChildren().add(toast);
        StackPane.setAlignment(toast, Pos.BOTTOM_RIGHT);
        StackPane.setMargin(toast, new javafx.geometry.Insets(0, 20, 20, 0)); // margin from bottom right

        FadeTransition fadeIn = new FadeTransition(Duration.seconds(0.3), toast);
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);

        FadeTransition fadeOut = new FadeTransition(Duration.seconds(0.4), toast);
        fadeOut.setFromValue(1);
        fadeOut.setToValue(0);
        fadeOut.setDelay(Duration.seconds(2.0));

        fadeIn.setOnFinished(e -> fadeOut.play());
        fadeOut.setOnFinished(e -> toastLayer.getChildren().remove(toast));

        Platform.runLater(fadeIn::play);
    }

    // Optional: if you still want to support directly passing a StackPane
    public static void show(StackPane root, String message) {
        show(root.getScene().getWindow(), message);
    }
}
