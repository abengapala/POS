package com.hardwarestore.pos;

public class Receipt {
  private final int    receiptId;
  private final String customerName;
  private final double totalAmount;
  private final double vat;
  private final String date;

  public Receipt(int receiptId, String customerName, double totalAmount, double vat, String date) {
    this.receiptId    = receiptId;
    this.customerName = customerName;
    this.totalAmount  = totalAmount;
    this.vat          = vat;
    this.date         = date;
  }
  public int    getReceiptId()   { return receiptId; }
  public String getCustomerName(){ return customerName; }
  public double getTotalAmount() { return totalAmount; }
  public double getVat()         { return vat; }
  public String getDate()        { return date; }
}
