package com.hardwarestore.pos.view;

import com.hardwarestore.pos.App;
import com.hardwarestore.pos.Database;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;

public class SettingsController {

    @FXML private TextField storeNameField;
    @FXML private TextField storeAddressField;
    @FXML private TextField storeContactField;
    @FXML private Spinner<Integer> thresholdSpinner;
    
    // Current logged in user
    private String currentUsername;

    @FXML
    public void initialize() {
        thresholdSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 1000, 10));

        // Load store info from DB
        Database db = new Database();
        String[] info = db.loadStoreInfo();
        storeNameField.setText(info[0]);
        storeAddressField.setText(info[1]);
        storeContactField.setText(info[2]);
        
        // This would typically be set when the user logs in
        // For now we'll use a default or you can modify to pass in the username
        currentUsername = "admin"; // Default value, should be set from login
    }
    
    public void setCurrentUsername(String username) {
        this.currentUsername = username;
    }

    // Store Info
    @FXML
    private void onSaveStoreInfo() {
        String name = storeNameField.getText();
        String address = storeAddressField.getText();
        String contact = storeContactField.getText();

        Database db = new Database();
        db.saveStoreInfo(name, address, contact);

        showAlert("Success", "Store information saved.");
    }

    // User/Admin Management
    @FXML
    private void onManageUsers() {
        UserManagementDialog dialog = new UserManagementDialog();
        dialog.showAndWait();
    }

    @FXML
    private void onChangePassword() {
        if (currentUsername == null || currentUsername.isEmpty()) {
            showAlert("Error", "No user is currently logged in.");
            return;
        }
        
        ChangePasswordDialog dialog = new ChangePasswordDialog(currentUsername);
        dialog.showAndWait();
    }

    // Stock Threshold
    @FXML
    private void onApplyThreshold() {
        int threshold = thresholdSpinner.getValue();
        System.out.println("🔔 Threshold set to: " + threshold);
        // TODO: Save to config or DB
        showAlert("Success", "Stock threshold applied.");
    }

    // Backup / Restore
    @FXML
    private void onBackup() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Save Backup File");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("SQL Files", "*.sql"));
        File file = fileChooser.showSaveDialog(getWindow());

        if (file != null) {
            System.out.println("💾 Backup saved to: " + file.getAbsolutePath());
            // TODO: Execute mysqldump
            showAlert("Success", "Backup saved successfully.");
        }
    }

    @FXML
    private void onRestore() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Backup File");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("SQL Files", "*.sql"));
        File file = fileChooser.showOpenDialog(getWindow());

        if (file != null) {
            System.out.println("📥 Restoring from: " + file.getAbsolutePath());
            // TODO: Execute MySQL import
            showAlert("Success", "Data restored successfully.");
        }
    }

    // Helpers
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

@FXML
private void onShowAboutDialog() {
    try {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/com/hardwarestore/pos/AboutDialog.fxml"));

        Parent root = loader.load();

        // 🛠 Inject HostServices
        AboutDialogController controller = loader.getController();
        controller.setHostServices(App.getInstance().getHostServices());

        Stage dialogStage = new Stage();
        dialogStage.initModality(Modality.APPLICATION_MODAL);
        dialogStage.setTitle("About Us");

        Scene scene = new Scene(root, 900, 700); // set preferred size
        dialogStage.setScene(scene);

        dialogStage.showAndWait();
    } catch (IOException e) {
        e.printStackTrace();
    }
}

@FXML
private void onOpenResearchPdf() {
    try {
        // Load the file from resources
        String resourcePath = "/research/Group4_POS-4.pdf";
        java.net.URL pdfUrl = getClass().getResource(resourcePath);

        if (pdfUrl != null) {
            File pdfFile = new File(pdfUrl.toURI());
            java.awt.Desktop.getDesktop().open(pdfFile);
        } else {
            showAlert("File Not Found", "The research PDF file could not be located in resources.");
        }
    } catch (Exception e) {
        showAlert("Error", "Unable to open the research PDF.");
        e.printStackTrace();
    }
}


    private Stage getWindow() {
        return (Stage) storeNameField.getScene().getWindow();
    }
}